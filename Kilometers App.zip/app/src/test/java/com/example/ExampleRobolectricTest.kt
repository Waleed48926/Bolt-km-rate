package com.example

import android.content.Context
import androidx.compose.ui.test.assertIsDisplayed
import androidx.compose.ui.test.assertTextContains
import androidx.compose.ui.test.hasTestTag
import androidx.compose.ui.test.junit4.createAndroidComposeRule
import androidx.compose.ui.test.onNodeWithTag
import androidx.compose.ui.test.performClick
import androidx.compose.ui.test.performScrollToNode
import androidx.test.core.app.ApplicationProvider
import org.junit.Assert.assertEquals
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36], qualifiers = "w411dp-h915dp-xxhdpi")
class ExampleRobolectricTest {

  @get:Rule val composeTestRule = createAndroidComposeRule<MainActivity>()

  @Test
  fun `read string from context`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val appName = context.getString(R.string.app_name)
    assertEquals("FareWise", appName)
  }

  @Test
  fun `evaluating quick offer updates movable PLN per km box`() {
    composeTestRule.waitForIdle()
    composeTestRule.onNodeWithTag("top_decision_box_standby").assertIsDisplayed()

    composeTestRule
      .onNodeWithTag("hud_lazy_column")
      .performScrollToNode(hasTestTag("evaluate_offer_button"))
    composeTestRule.waitForIdle()

    composeTestRule.onNodeWithTag("evaluate_offer_button").performClick()
    composeTestRule.mainClock.advanceTimeBy(600)
    composeTestRule.waitForIdle()

    composeTestRule.onNodeWithTag("top_decision_box_active").assertIsDisplayed()
    composeTestRule.onNodeWithTag("top_box_pln_per_km").assertIsDisplayed()
    composeTestRule.onNodeWithTag("top_box_pln_per_km").assertTextContains("3.76", substring = true)
  }
}
