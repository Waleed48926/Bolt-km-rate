package com.example

import com.example.domain.IncomingRideOffer
import com.example.domain.ProfitGoals
import com.example.domain.Recommendation
import com.example.domain.RideDecisionEngine
import com.example.domain.RidePlatform
import com.example.domain.RideTextParser
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Test

class RideDecisionEngineTest {

  @Test
  fun `evaluates high pln per km ride as ACCEPT`() {
    val goals = ProfitGoals(targetPlnPerKm = 3.20, minPlnPerKm = 2.40, includePickupDistance = true)
    val offer =
      IncomingRideOffer(
        id = "1",
        platform = RidePlatform.BOLT,
        grossFarePln = 44.0,
        pickupKm = 1.0,
        tripKm = 9.0,
      )

    val result = RideDecisionEngine.evaluate(offer, goals)

    assertEquals(Recommendation.ACCEPT, result.recommendation)
    assertEquals(4.40, result.grossPlnPerKm, 0.01)
    assertEquals(10.0, result.totalKm, 0.01)
  }

  @Test
  fun `evaluates low pln per km ride as REJECT`() {
    val goals = ProfitGoals(targetPlnPerKm = 3.20, minPlnPerKm = 2.40, includePickupDistance = true)
    val offer =
      IncomingRideOffer(
        id = "2",
        platform = RidePlatform.UBER,
        grossFarePln = 15.0,
        pickupKm = 2.5,
        tripKm = 6.5,
      )

    val result = RideDecisionEngine.evaluate(offer, goals)

    assertEquals(Recommendation.REJECT, result.recommendation)
    assertEquals(1.67, result.grossPlnPerKm, 0.02)
  }

  @Test
  fun `parses Polish Bolt offer with comma decimal and meters`() {
    val raw = "Bolt\n38,50 zł\n650 m • 3 min\n9,35 km • 18 min\n1,4x"
    val parsed = RideTextParser.parse(raw, packageName = "ee.mtakso.driver")

    assertNotNull(parsed)
    assertEquals(RidePlatform.BOLT, parsed!!.platform)
    assertEquals(38.50, parsed.grossFarePln, 0.01)
    assertEquals(0.65, parsed.pickupKm, 0.01)
    assertEquals(9.35, parsed.tripKm, 0.01)
    assertEquals(1.4, parsed.surgeMultiplier ?: 0.0, 0.01)
  }

  @Test
  fun `parses Bolt screenshot offer with prefix zl`() {
    val raw = "Bolt\n1.3x High demand\nzł 37.50 (NET, tax included)\n6 min • 3 km\n27 min • 13.9 km"
    val parsed = RideTextParser.parse(raw, packageName = "ee.mtakso.driver")

    assertNotNull(parsed)
    assertEquals(RidePlatform.BOLT, parsed!!.platform)
    assertEquals(37.50, parsed.grossFarePln, 0.01)
    assertEquals(3.0, parsed.pickupKm, 0.01)
    assertEquals(13.9, parsed.tripKm, 0.01)
    assertEquals(1.3, parsed.surgeMultiplier ?: 0.0, 0.01)
  }

  @Test
  fun `parses English Uber PLN offer`() {
    val raw = "UberX\nPLN 48.00\n1.5 km away\n10.5 km trip"
    val parsed = RideTextParser.parse(raw, packageName = "com.ubercab.driver")

    assertNotNull(parsed)
    assertEquals(RidePlatform.UBER, parsed!!.platform)
    assertEquals(48.0, parsed.grossFarePln, 0.01)
    assertEquals(1.5, parsed.pickupKm, 0.01)
    assertEquals(10.5, parsed.tripKm, 0.01)
  }
}
