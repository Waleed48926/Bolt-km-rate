package com.example

import android.app.Application
import com.example.data.GoalsPreferencesRepository
import com.example.data.RideDatabase
import com.example.data.RideRepository

class FareWiseApplication : Application() {
  lateinit var repository: RideRepository
    private set

  override fun onCreate() {
    super.onCreate()
    val goalsRepo = GoalsPreferencesRepository(this)
    val database = RideDatabase.getInstance(this)
    repository = RideRepository(goalsRepo, database.rideEvaluationDao())
  }
}
