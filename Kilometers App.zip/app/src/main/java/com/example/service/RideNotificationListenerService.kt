package com.example.service

import android.app.Notification
import android.provider.Settings
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import com.example.FareWiseApplication
import com.example.domain.RideTextParser
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch

class RideNotificationListenerService : NotificationListenerService() {

  private val serviceScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

  override fun onNotificationPosted(sbn: StatusBarNotification?) {
    val pkg = sbn?.packageName ?: return
    if (!TARGET_PACKAGES.contains(pkg)) return

    val extras = sbn.notification?.extras ?: return
    val title = extras.getCharSequence(Notification.EXTRA_TITLE)?.toString().orEmpty()
    val text = extras.getCharSequence(Notification.EXTRA_TEXT)?.toString().orEmpty()
    val bigText = extras.getCharSequence(Notification.EXTRA_BIG_TEXT)?.toString().orEmpty()
    val combined = listOf(title, text, bigText).filter { it.isNotBlank() }.joinToString("\n")
    if (combined.isBlank()) return

    val parsedOffer = RideTextParser.parse(combined, packageName = pkg) ?: return
    serviceScope.launch {
      val app = application as FareWiseApplication
      val evaluated = app.repository.submitOffer(parsedOffer, deduplicate = true)
      if (evaluated != null && Settings.canDrawOverlays(this@RideNotificationListenerService)) {
        TopOverlayService.start(this@RideNotificationListenerService)
      }
    }
  }

  override fun onDestroy() {
    serviceScope.cancel()
    super.onDestroy()
  }

  companion object {
    private val TARGET_PACKAGES =
      setOf(
        "ee.mtakso.driver",
        "com.bolt.driver",
        "com.ubercab.driver",
      )
  }
}
