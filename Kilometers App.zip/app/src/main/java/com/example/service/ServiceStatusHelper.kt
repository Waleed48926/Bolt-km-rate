package com.example.service

import android.Manifest
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.provider.Settings
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat

data class SystemIntegrationStatus(
  val overlayGranted: Boolean,
  val accessibilityEnabled: Boolean,
  val notificationListenerEnabled: Boolean,
  val postNotificationsGranted: Boolean,
)

object ServiceStatusHelper {

  fun getStatus(context: Context): SystemIntegrationStatus {
    return SystemIntegrationStatus(
      overlayGranted = Settings.canDrawOverlays(context),
      accessibilityEnabled = isAccessibilityServiceEnabled(context),
      notificationListenerEnabled = isNotificationListenerEnabled(context),
      postNotificationsGranted = isPostNotificationsGranted(context),
    )
  }

  fun isAccessibilityServiceEnabled(context: Context): Boolean {
    val expected = ComponentName(context, RideAccessibilityService::class.java).flattenToString()
    val enabledServices =
      Settings.Secure.getString(
        context.contentResolver,
        Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES,
      ) ?: return false
    return enabledServices.split(':').any { it.equals(expected, ignoreCase = true) }
  }

  fun isNotificationListenerEnabled(context: Context): Boolean {
    val enabledPackages = NotificationManagerCompat.getEnabledListenerPackages(context)
    return enabledPackages.contains(context.packageName)
  }

  fun isPostNotificationsGranted(context: Context): Boolean {
    return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
      ContextCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS) ==
        PackageManager.PERMISSION_GRANTED
    } else {
      true
    }
  }

  fun overlaySettingsIntent(context: Context): Intent {
    return Intent(
      Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
      Uri.parse("package:${context.packageName}"),
    )
  }

  fun accessibilitySettingsIntent(): Intent {
    return Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)
  }

  fun notificationListenerSettingsIntent(): Intent {
    return Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS)
  }
}
