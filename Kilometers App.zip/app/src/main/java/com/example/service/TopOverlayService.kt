package com.example.service

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.IBinder
import android.provider.Settings
import android.util.TypedValue
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.LinearLayout
import android.widget.TextView
import androidx.core.app.NotificationCompat
import com.example.FareWiseApplication
import com.example.MainActivity
import com.example.R
import com.example.domain.EvaluatedRide
import com.example.domain.ProfitGoals
import com.example.domain.Recommendation
import com.example.domain.RideDecisionEngine
import kotlin.math.abs
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.launch

class TopOverlayService : Service() {

  private val serviceScope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)
  private var windowManager: WindowManager? = null
  private var overlayView: View? = null
  private var layoutParams: WindowManager.LayoutParams? = null
  private var autoHideJob: Job? = null

  private var rateValueView: TextView? = null
  private var rateUnitView: TextView? = null
  private var cardContainerView: LinearLayout? = null

  private var savedX: Int? = null
  private var savedY: Int? = null

  override fun onCreate() {
    super.onCreate()
    _isRunning.value = true
    windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
    createNotificationChannel()
    startAsForeground()
    observeActiveRide()
  }

  override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
    when (intent?.action) {
      ACTION_STOP -> {
        removeOverlayView()
        stopSelf()
        return START_NOT_STICKY
      }
      ACTION_REFRESH -> {
        val repo = (application as FareWiseApplication).repository
        val active = repo.activeEvaluatedRide.value
        if (active != null && Settings.canDrawOverlays(this)) {
          showOrUpdateOverlay(active, ProfitGoals())
        }
      }
    }
    return START_STICKY
  }

  override fun onBind(intent: Intent?): IBinder? = null

  override fun onDestroy() {
    _isRunning.value = false
    autoHideJob?.cancel()
    removeOverlayView()
    serviceScope.cancel()
    super.onDestroy()
  }

  private fun startAsForeground() {
    val notification = buildNotification()
    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
      startForeground(
        NOTIFICATION_ID,
        notification,
        ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC,
      )
    } else {
      startForeground(NOTIFICATION_ID, notification)
    }
  }

  private fun observeActiveRide() {
    val repo = (application as FareWiseApplication).repository
    serviceScope.launch {
      combine(repo.activeEvaluatedRide, repo.goalsFlow) { ride, goals -> ride to goals }
        .collect { (ride, goals) ->
          if (ride != null && goals.overlayEnabled && Settings.canDrawOverlays(this@TopOverlayService)) {
            showOrUpdateOverlay(ride, goals)
          } else {
            removeOverlayView()
          }
        }
    }
  }

  private fun showOrUpdateOverlay(ride: EvaluatedRide, goals: ProfitGoals) {
    if (!Settings.canDrawOverlays(this)) return
    if (overlayView == null) {
      overlayView = createOverlayView()
      val layoutType =
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
          WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        } else {
          @Suppress("DEPRECATION")
          WindowManager.LayoutParams.TYPE_PHONE
        }
      val params =
        WindowManager.LayoutParams(
          WindowManager.LayoutParams.WRAP_CONTENT,
          WindowManager.LayoutParams.WRAP_CONTENT,
          layoutType,
          WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
            WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
          PixelFormat.TRANSLUCENT,
        ).apply {
          gravity = Gravity.TOP or Gravity.START
          x = savedX ?: dpToPx(12)
          y = savedY ?: (getStatusBarHeight() + dpToPx(8))
        }
      layoutParams = params
      attachDragListener(overlayView!!, params)
      runCatching { windowManager?.addView(overlayView, params) }
    }

    bindRideData(ride)

    autoHideJob?.cancel()
    autoHideJob =
      serviceScope.launch {
        delay(goals.autoHideSeconds * 1000L)
        removeOverlayView()
      }
  }

  private fun createOverlayView(): View {
    val root =
      LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        minimumWidth = dpToPx(148)
        background =
          GradientDrawable().apply {
            shape = GradientDrawable.RECTANGLE
            cornerRadius = dpToPx(10).toFloat()
            setColor(Color.parseColor("#EB16181D"))
            setStroke(dpToPx(2), Color.parseColor("#EAB308"))
          }
        elevation = dpToPx(8).toFloat()
        clipToOutline = true
      }
    cardContainerView = root

    // Subtle taxi checkered strip matching reference box
    val checkerStrip =
      TaxiCheckerView(this).apply {
        layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dpToPx(5))
      }
    root.addView(checkerStrip)

    val contentRow =
      LinearLayout(this).apply {
        orientation = LinearLayout.HORIZONTAL
        gravity = Gravity.CENTER_VERTICAL
        setPadding(dpToPx(12), dpToPx(8), dpToPx(6), dpToPx(10))
      }
    root.addView(contentRow)

    val rateRow =
      LinearLayout(this).apply {
        orientation = LinearLayout.HORIZONTAL
        gravity = Gravity.BOTTOM
      }
    contentRow.addView(rateRow)

    val rateVal =
      TextView(this).apply {
        setTextSize(TypedValue.COMPLEX_UNIT_SP, 22f)
        setTypeface(Typeface.DEFAULT_BOLD)
        setTextColor(Color.parseColor("#10E584"))
      }
    rateValueView = rateVal
    rateRow.addView(rateVal)

    val rateUnit =
      TextView(this).apply {
        text = " PLN/km"
        setTextSize(TypedValue.COMPLEX_UNIT_SP, 12f)
        setTypeface(Typeface.DEFAULT_BOLD)
        setTextColor(Color.parseColor("#CBD5E1"))
        setPadding(0, 0, dpToPx(6), dpToPx(2))
      }
    rateUnitView = rateUnit
    rateRow.addView(rateUnit)

    val closeButton =
      TextView(this).apply {
        text = "✕"
        textSize = 13f
        setTextColor(Color.parseColor("#94A3B8"))
        gravity = Gravity.CENTER
        minWidth = dpToPx(30)
        minHeight = dpToPx(30)
        setOnClickListener {
          (application as FareWiseApplication).repository.dismissActiveOffer()
          removeOverlayView()
        }
      }
    contentRow.addView(closeButton)

    return root
  }

  private fun attachDragListener(view: View, params: WindowManager.LayoutParams) {
    var initialX = 0
    var initialY = 0
    var initialTouchX = 0f
    var initialTouchY = 0f
    var dragging = false

    view.setOnTouchListener { _, event ->
      when (event.action) {
        MotionEvent.ACTION_DOWN -> {
          initialX = params.x
          initialY = params.y
          initialTouchX = event.rawX
          initialTouchY = event.rawY
          dragging = false
          true
        }
        MotionEvent.ACTION_MOVE -> {
          val dx = (event.rawX - initialTouchX).toInt()
          val dy = (event.rawY - initialTouchY).toInt()
          if (abs(dx) > 6 || abs(dy) > 6) {
            dragging = true
          }
          val maxW = (resources.displayMetrics.widthPixels - view.width).coerceAtLeast(0)
          val maxH = (resources.displayMetrics.heightPixels - view.height).coerceAtLeast(0)
          params.x = (initialX + dx).coerceIn(0, maxW)
          params.y = (initialY + dy).coerceIn(0, maxH)
          savedX = params.x
          savedY = params.y
          runCatching { windowManager?.updateViewLayout(view, params) }
          true
        }
        MotionEvent.ACTION_UP -> dragging
        else -> false
      }
    }
  }

  private fun bindRideData(ride: EvaluatedRide) {
    val signalColor =
      when (ride.recommendation) {
        Recommendation.ACCEPT -> Color.parseColor("#10E584")
        Recommendation.BORDERLINE -> Color.parseColor("#FFB020")
        Recommendation.REJECT -> Color.parseColor("#FF4757")
      }
    rateValueView?.apply {
      text = RideDecisionEngine.formatPln(ride.grossPlnPerKm)
      setTextColor(signalColor)
    }
    rateUnitView?.setTextColor(signalColor)
    (cardContainerView?.background as? GradientDrawable)?.setStroke(
      dpToPx(2),
      Color.parseColor("#EAB308"),
    )
  }

  private fun removeOverlayView() {
    val view = overlayView ?: return
    runCatching { windowManager?.removeView(view) }
    overlayView = null
    layoutParams = null
  }

  private fun createNotificationChannel() {
    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
      val channel =
        NotificationChannel(
          CHANNEL_ID,
          getString(R.string.overlay_channel_name),
          NotificationManager.IMPORTANCE_LOW,
        ).apply { description = getString(R.string.overlay_channel_description) }
      val manager = getSystemService(NotificationManager::class.java)
      manager.createNotificationChannel(channel)
    }
  }

  private fun buildNotification(): Notification {
    val openIntent =
      PendingIntent.getActivity(
        this,
        0,
        Intent(this, MainActivity::class.java),
        PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT,
      )
    val stopIntent =
      PendingIntent.getService(
        this,
        1,
        Intent(this, TopOverlayService::class.java).apply { action = ACTION_STOP },
        PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT,
      )
    return NotificationCompat.Builder(this, CHANNEL_ID)
      .setContentTitle("FareWise Box Active")
      .setContentText("Showing PLN/km box for incoming Bolt & Uber rides")
      .setSmallIcon(R.drawable.ic_launcher_foreground)
      .setOngoing(true)
      .setContentIntent(openIntent)
      .addAction(0, "Stop", stopIntent)
      .build()
  }

  private fun getStatusBarHeight(): Int {
    val resourceId = resources.getIdentifier("status_bar_height", "dimen", "android")
    return if (resourceId > 0) resources.getDimensionPixelSize(resourceId) else dpToPx(24)
  }

  private fun dpToPx(dp: Int): Int {
    return (dp * resources.displayMetrics.density).toInt()
  }

  private class TaxiCheckerView(context: Context) : View(context) {
    private val goldPaint = Paint().apply { color = Color.parseColor("#EAB308") }
    private val darkPaint = Paint().apply { color = Color.parseColor("#111318") }

    override fun onDraw(canvas: Canvas) {
      super.onDraw(canvas)
      val cell = height.toFloat().coerceAtLeast(4f)
      var x = 0f
      var index = 0
      while (x < width) {
        canvas.drawRect(x, 0f, x + cell, height.toFloat(), if (index % 2 == 0) goldPaint else darkPaint)
        x += cell
        index++
      }
    }
  }

  companion object {
    private const val CHANNEL_ID = "farewise_hud_channel"
    private const val NOTIFICATION_ID = 4102
    const val ACTION_STOP = "com.example.action.STOP_OVERLAY"
    const val ACTION_REFRESH = "com.example.action.REFRESH_OVERLAY"

    private val _isRunning = MutableStateFlow(false)
    val isRunning: StateFlow<Boolean> = _isRunning.asStateFlow()

    fun start(context: Context) {
      val intent = Intent(context, TopOverlayService::class.java).apply { action = ACTION_REFRESH }
      if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
        context.startForegroundService(intent)
      } else {
        context.startService(intent)
      }
    }

    fun stop(context: Context) {
      val intent = Intent(context, TopOverlayService::class.java).apply { action = ACTION_STOP }
      context.startService(intent)
    }
  }
}
