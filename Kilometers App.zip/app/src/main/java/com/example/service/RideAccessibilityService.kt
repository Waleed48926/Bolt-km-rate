package com.example.service

import android.accessibilityservice.AccessibilityService
import android.provider.Settings
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import com.example.FareWiseApplication
import com.example.domain.RideTextParser
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch

class RideAccessibilityService : AccessibilityService() {

  private val serviceScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

  override fun onAccessibilityEvent(event: AccessibilityEvent?) {
    val packageName = event?.packageName?.toString() ?: return
    if (!TARGET_PACKAGES.contains(packageName)) return

    val root = rootInActiveWindow ?: return
    val collected = StringBuilder()
    collectNodeText(root, collected, depth = 0)

    val rawText = collected.toString()
    if (rawText.isBlank()) return

    val parsedOffer = RideTextParser.parse(rawText, packageName = packageName) ?: return
    serviceScope.launch {
      val app = application as FareWiseApplication
      val evaluated = app.repository.submitOffer(parsedOffer, deduplicate = true)
      if (evaluated != null && Settings.canDrawOverlays(this@RideAccessibilityService)) {
        TopOverlayService.start(this@RideAccessibilityService)
      }
    }
  }

  override fun onInterrupt() = Unit

  override fun onDestroy() {
    serviceScope.cancel()
    super.onDestroy()
  }

  private fun collectNodeText(node: AccessibilityNodeInfo?, out: StringBuilder, depth: Int) {
    if (node == null || depth > 14) return
    val text = node.text?.toString()?.trim()
    if (!text.isNullOrEmpty()) {
      out.append(text).append('\n')
    }
    val desc = node.contentDescription?.toString()?.trim()
    if (!desc.isNullOrEmpty() && desc != text) {
      out.append(desc).append('\n')
    }
    for (i in 0 until node.childCount) {
      collectNodeText(node.getChild(i), out, depth + 1)
    }
  }

  companion object {
    private val TARGET_PACKAGES =
      setOf(
        "ee.mtakso.driver",
        "com.bolt.driver",
        "com.ubercab.driver",
      )
  }
}
