package com.example.data

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

@Database(entities = [RideEvaluationEntity::class], version = 1, exportSchema = false)
abstract class RideDatabase : RoomDatabase() {
  abstract fun rideEvaluationDao(): RideEvaluationDao

  companion object {
    @Volatile private var INSTANCE: RideDatabase? = null

    fun getInstance(context: Context): RideDatabase {
      return INSTANCE
        ?: synchronized(this) {
          INSTANCE
            ?: Room.databaseBuilder(
                context.applicationContext,
                RideDatabase::class.java,
                "farewise_rides.db",
              )
              .build()
              .also { INSTANCE = it }
        }
    }
  }
}
