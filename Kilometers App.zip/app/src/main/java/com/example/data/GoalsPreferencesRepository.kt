package com.example.data

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.doublePreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import com.example.domain.ProfitGoals
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.goalsDataStore: DataStore<Preferences> by preferencesDataStore(name = "farewise_goals")

class GoalsPreferencesRepository(private val context: Context) {

  private object Keys {
    val TARGET_PLN_PER_KM = doublePreferencesKey("target_pln_per_km")
    val MIN_PLN_PER_KM = doublePreferencesKey("min_pln_per_km")
    val MIN_FARE_PLN = doublePreferencesKey("min_fare_pln")
    val MAX_PICKUP_KM = doublePreferencesKey("max_pickup_km")
    val INCLUDE_PICKUP = booleanPreferencesKey("include_pickup_distance")
    val BOLT_COMMISSION = doublePreferencesKey("bolt_commission_percent")
    val UBER_COMMISSION = doublePreferencesKey("uber_commission_percent")
    val FUEL_COST_PER_KM = doublePreferencesKey("fuel_cost_per_km")
    val AUTO_HIDE_SECONDS = intPreferencesKey("auto_hide_seconds")
    val OVERLAY_ENABLED = booleanPreferencesKey("overlay_enabled")
  }

  val goalsFlow: Flow<ProfitGoals> =
    context.goalsDataStore.data.map { prefs ->
      val target = prefs[Keys.TARGET_PLN_PER_KM] ?: 3.20
      val minRate = (prefs[Keys.MIN_PLN_PER_KM] ?: 2.40).coerceAtMost(target)
      ProfitGoals(
        targetPlnPerKm = target,
        minPlnPerKm = minRate,
        minFarePln = prefs[Keys.MIN_FARE_PLN] ?: 15.0,
        maxPickupKm = prefs[Keys.MAX_PICKUP_KM] ?: 3.5,
        includePickupDistance = prefs[Keys.INCLUDE_PICKUP] ?: true,
        boltCommissionPercent = prefs[Keys.BOLT_COMMISSION] ?: 25.0,
        uberCommissionPercent = prefs[Keys.UBER_COMMISSION] ?: 25.0,
        fuelCostPerKmPln = prefs[Keys.FUEL_COST_PER_KM] ?: 0.55,
        autoHideSeconds = prefs[Keys.AUTO_HIDE_SECONDS] ?: 18,
        overlayEnabled = prefs[Keys.OVERLAY_ENABLED] ?: true,
      )
    }

  suspend fun updateGoals(transform: (ProfitGoals) -> ProfitGoals) {
    context.goalsDataStore.edit { prefs ->
      val current =
        ProfitGoals(
          targetPlnPerKm = prefs[Keys.TARGET_PLN_PER_KM] ?: 3.20,
          minPlnPerKm = prefs[Keys.MIN_PLN_PER_KM] ?: 2.40,
          minFarePln = prefs[Keys.MIN_FARE_PLN] ?: 15.0,
          maxPickupKm = prefs[Keys.MAX_PICKUP_KM] ?: 3.5,
          includePickupDistance = prefs[Keys.INCLUDE_PICKUP] ?: true,
          boltCommissionPercent = prefs[Keys.BOLT_COMMISSION] ?: 25.0,
          uberCommissionPercent = prefs[Keys.UBER_COMMISSION] ?: 25.0,
          fuelCostPerKmPln = prefs[Keys.FUEL_COST_PER_KM] ?: 0.55,
          autoHideSeconds = prefs[Keys.AUTO_HIDE_SECONDS] ?: 18,
          overlayEnabled = prefs[Keys.OVERLAY_ENABLED] ?: true,
        )
      val updated = transform(current)
      prefs[Keys.TARGET_PLN_PER_KM] = updated.targetPlnPerKm.coerceIn(1.5, 10.0)
      prefs[Keys.MIN_PLN_PER_KM] =
        updated.minPlnPerKm.coerceIn(1.0, updated.targetPlnPerKm.coerceIn(1.5, 10.0))
      prefs[Keys.MIN_FARE_PLN] = updated.minFarePln.coerceIn(5.0, 100.0)
      prefs[Keys.MAX_PICKUP_KM] = updated.maxPickupKm.coerceIn(0.5, 15.0)
      prefs[Keys.INCLUDE_PICKUP] = updated.includePickupDistance
      prefs[Keys.BOLT_COMMISSION] = updated.boltCommissionPercent.coerceIn(0.0, 50.0)
      prefs[Keys.UBER_COMMISSION] = updated.uberCommissionPercent.coerceIn(0.0, 50.0)
      prefs[Keys.FUEL_COST_PER_KM] = updated.fuelCostPerKmPln.coerceIn(0.0, 3.0)
      prefs[Keys.AUTO_HIDE_SECONDS] = updated.autoHideSeconds.coerceIn(5, 60)
      prefs[Keys.OVERLAY_ENABLED] = updated.overlayEnabled
    }
  }
}
