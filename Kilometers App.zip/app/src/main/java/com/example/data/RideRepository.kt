package com.example.data

import com.example.domain.DriverAction
import com.example.domain.EvaluatedRide
import com.example.domain.IncomingRideOffer
import com.example.domain.ProfitGoals
import com.example.domain.RideDecisionEngine
import com.example.domain.RideTextParser
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

class RideRepository(
  private val goalsRepository: GoalsPreferencesRepository,
  private val rideDao: RideEvaluationDao,
) {
  private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

  private val _activeEvaluatedRide = MutableStateFlow<EvaluatedRide?>(null)
  val activeEvaluatedRide: StateFlow<EvaluatedRide?> = _activeEvaluatedRide.asStateFlow()

  @Volatile private var cachedGoals: ProfitGoals = ProfitGoals()
  private var lastSignature: String = ""
  private var lastOfferTimestamp: Long = 0L

  val goalsFlow: Flow<ProfitGoals> = goalsRepository.goalsFlow
  val evaluationsFlow: Flow<List<RideEvaluationEntity>> = rideDao.observeAll()

  init {
    scope.launch {
      goalsRepository.goalsFlow.collect { latest ->
        cachedGoals = latest
      }
    }
  }

  suspend fun updateGoals(transform: (ProfitGoals) -> ProfitGoals) {
    goalsRepository.updateGoals(transform)
    val updatedGoals = transform(cachedGoals)
    cachedGoals = updatedGoals
    val current = _activeEvaluatedRide.value
    if (current != null) {
      _activeEvaluatedRide.value = RideDecisionEngine.evaluate(current.offer, updatedGoals)
    }
  }

  fun submitOffer(
    offer: IncomingRideOffer,
    deduplicate: Boolean = false,
  ): EvaluatedRide? {
    val now = System.currentTimeMillis()
    val signature = RideTextParser.buildSignature(offer)
    if (deduplicate && signature == lastSignature && (now - lastOfferTimestamp) < 8_000L) {
      return null
    }
    lastSignature = signature
    lastOfferTimestamp = now

    val evaluated = RideDecisionEngine.evaluate(offer, cachedGoals)
    _activeEvaluatedRide.value = evaluated

    scope.launch {
      rideDao.insert(
        RideEvaluationEntity(
          id = offer.id,
          platform = offer.platform.name,
          grossFarePln = offer.grossFarePln,
          pickupKm = offer.pickupKm,
          tripKm = offer.tripKm,
          totalKm = evaluated.totalKm,
          effectiveKm = evaluated.effectiveKm,
          grossPlnPerKm = evaluated.grossPlnPerKm,
          netProfitPln = evaluated.netProfitPln,
          netPlnPerKm = evaluated.netPlnPerKm,
          recommendation = evaluated.recommendation.name,
          reason = evaluated.reason,
          driverAction = DriverAction.PENDING.name,
          isSimulated = offer.isSimulated,
          timestampMillis = offer.detectedAtMillis,
        )
      )
    }
    return evaluated
  }

  fun recordActiveDriverAction(action: DriverAction) {
    val active = _activeEvaluatedRide.value ?: return
    _activeEvaluatedRide.value = null
    scope.launch { rideDao.updateDriverAction(active.offer.id, action.name) }
  }

  fun dismissActiveOffer() {
    val active = _activeEvaluatedRide.value ?: return
    _activeEvaluatedRide.value = null
    scope.launch { rideDao.updateDriverAction(active.offer.id, DriverAction.DISMISSED.name) }
  }

  suspend fun deleteEvaluation(id: String) {
    rideDao.deleteById(id)
  }

  suspend fun clearHistory() {
    rideDao.clearAll()
  }
}
