package com.example.data

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface RideEvaluationDao {

  @Query("SELECT * FROM ride_evaluations ORDER BY timestampMillis DESC")
  fun observeAll(): Flow<List<RideEvaluationEntity>>

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insert(entity: RideEvaluationEntity)

  @Query("UPDATE ride_evaluations SET driverAction = :action WHERE id = :id")
  suspend fun updateDriverAction(id: String, action: String)

  @Query("DELETE FROM ride_evaluations WHERE id = :id")
  suspend fun deleteById(id: String)

  @Query("DELETE FROM ride_evaluations")
  suspend fun clearAll()
}
