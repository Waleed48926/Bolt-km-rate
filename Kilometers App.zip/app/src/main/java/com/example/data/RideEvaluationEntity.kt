package com.example.data

import androidx.room.Entity
import androidx.room.PrimaryKey
import com.example.domain.DriverAction
import com.example.domain.Recommendation
import com.example.domain.RidePlatform

@Entity(tableName = "ride_evaluations")
data class RideEvaluationEntity(
  @PrimaryKey val id: String,
  val platform: String,
  val grossFarePln: Double,
  val pickupKm: Double,
  val tripKm: Double,
  val totalKm: Double,
  val effectiveKm: Double,
  val grossPlnPerKm: Double,
  val netProfitPln: Double,
  val netPlnPerKm: Double,
  val recommendation: String,
  val reason: String,
  val driverAction: String,
  val isSimulated: Boolean,
  val timestampMillis: Long,
) {
  fun platformEnum(): RidePlatform =
    RidePlatform.entries.firstOrNull { it.name == platform } ?: RidePlatform.MANUAL

  fun recommendationEnum(): Recommendation =
    Recommendation.entries.firstOrNull { it.name == recommendation } ?: Recommendation.BORDERLINE

  fun driverActionEnum(): DriverAction =
    DriverAction.entries.firstOrNull { it.name == driverAction } ?: DriverAction.PENDING
}
