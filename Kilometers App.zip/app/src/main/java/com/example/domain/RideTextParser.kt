package com.example.domain

import java.util.UUID

object RideTextParser {

  private val plnPostfixRegex =
    Regex("""(\d{1,4}(?:[.,]\d{1,2})?)[ \t]*(?:zł|zl|PLN)(?![\p{L}\d])""", RegexOption.IGNORE_CASE)
  private val plnPrefixRegex =
    Regex("""(?<![\p{L}\d])(?:PLN|zł|zl)[ \t]*(\d{1,4}(?:[.,]\d{1,2})?)""", RegexOption.IGNORE_CASE)
  private val kmRegex = Regex("""(\d{1,3}(?:[.,]\d{1,2})?)[ \t]*km(?![\p{L}\d])""", RegexOption.IGNORE_CASE)
  private val meterRegex = Regex("""(\d{2,4})[ \t]*m(?![\p{L}\d])""", RegexOption.IGNORE_CASE)
  private val minuteRegex = Regex("""(\d{1,3})[ \t]*min(?![\p{L}\d])""", RegexOption.IGNORE_CASE)
  private val surgeRegex =
    Regex("""(?:(\d(?:[.,]\d{1,2})?)[ \t]*x|x[ \t]*(\d(?:[.,]\d{1,2})?))""", RegexOption.IGNORE_CASE)

  fun detectPlatform(packageName: String?, rawText: String): RidePlatform {
    val pkg = packageName.orEmpty().lowercase()
    return when {
      pkg.contains("mtakso") || pkg.contains("bolt") -> RidePlatform.BOLT
      pkg.contains("ubercab") || pkg.contains("uber") -> RidePlatform.UBER
      rawText.contains("bolt", ignoreCase = true) -> RidePlatform.BOLT
      rawText.contains("uber", ignoreCase = true) -> RidePlatform.UBER
      else -> RidePlatform.MANUAL
    }
  }

  fun parse(
    rawText: String,
    packageName: String? = null,
    isSimulated: Boolean = false,
  ): IncomingRideOffer? {
    if (rawText.isBlank()) return null

    val farePln = extractFarePln(rawText) ?: return null
    if (farePln < 4.0 || farePln > 2500.0) return null

    val distancesKm = extractDistancesKm(rawText)
    if (distancesKm.isEmpty()) return null

    val pickupKm: Double
    val tripKm: Double
    if (distancesKm.size >= 2) {
      pickupKm = distancesKm[0]
      tripKm = distancesKm[1]
    } else {
      pickupKm = 0.0
      tripKm = distancesKm[0]
    }

    if (pickupKm + tripKm < 0.1 || pickupKm + tripKm > 500.0) return null

    val durationMinutes = minuteRegex.findAll(rawText).mapNotNull { it.groupValues[1].toIntOrNull() }.sum().takeIf { it > 0 }
    val surge = extractSurge(rawText)
    val platform = detectPlatform(packageName, rawText)

    return IncomingRideOffer(
      id = UUID.randomUUID().toString(),
      platform = platform,
      grossFarePln = farePln,
      pickupKm = pickupKm,
      tripKm = tripKm,
      durationMinutes = durationMinutes,
      surgeMultiplier = surge,
      detectedAtMillis = System.currentTimeMillis(),
      isSimulated = isSimulated,
    )
  }

  fun buildSignature(offer: IncomingRideOffer): String {
    return "${offer.platform.name}|${RideDecisionEngine.formatPln(offer.grossFarePln)}|${RideDecisionEngine.formatKm(offer.pickupKm)}|${RideDecisionEngine.formatKm(offer.tripKm)}"
  }

  private fun extractFarePln(text: String): Double? {
    val candidates = mutableListOf<Double>()
    plnPostfixRegex.findAll(text).forEach { match ->
      parseDecimal(match.groupValues[1])?.let { candidates.add(it) }
    }
    plnPrefixRegex.findAll(text).forEach { match ->
      parseDecimal(match.groupValues[1])?.let { candidates.add(it) }
    }
    return candidates.firstOrNull { it >= 4.0 }
  }

  private fun extractDistancesKm(text: String): List<Double> {
    data class IndexedDistance(val index: Int, val km: Double)

    val found = mutableListOf<IndexedDistance>()
    kmRegex.findAll(text).forEach { match ->
      val km = parseDecimal(match.groupValues[1])
      if (km != null && km > 0.0 && km <= 400.0) {
        found.add(IndexedDistance(match.range.first, km))
      }
    }
    meterRegex.findAll(text).forEach { match ->
      val meters = match.groupValues[1].toDoubleOrNull()
      if (meters != null && meters >= 50.0 && meters <= 9999.0) {
        found.add(IndexedDistance(match.range.first, meters / 1000.0))
      }
    }
    return found.sortedBy { it.index }.map { it.km }
  }

  private fun extractSurge(text: String): Double? {
    val match = surgeRegex.find(text) ?: return null
    val raw = match.groupValues[1].ifBlank { match.groupValues[2] }
    val parsed = parseDecimal(raw) ?: return null
    return parsed.takeIf { it in 1.05..10.0 }
  }

  private fun parseDecimal(raw: String): Double? {
    return raw.trim().replace(',', '.').toDoubleOrNull()
  }
}
