package com.example.domain

import java.util.Locale
import kotlin.math.max

object RideDecisionEngine {

  fun evaluate(offer: IncomingRideOffer, goals: ProfitGoals): EvaluatedRide {
    val safePickup = max(0.0, offer.pickupKm)
    val safeTrip = max(0.0, offer.tripKm)
    val totalKm = max(0.1, safePickup + safeTrip)
    val effectiveKm =
      if (goals.includePickupDistance) {
        totalKm
      } else {
        max(0.1, if (safeTrip > 0.0) safeTrip else totalKm)
      }

    val grossPlnPerKm = offer.grossFarePln / effectiveKm
    val commissionRate =
      when (offer.platform) {
        RidePlatform.BOLT -> goals.boltCommissionPercent / 100.0
        RidePlatform.UBER -> goals.uberCommissionPercent / 100.0
        RidePlatform.MANUAL -> goals.boltCommissionPercent / 100.0
      }.coerceIn(0.0, 0.8)

    val commissionPln = offer.grossFarePln * commissionRate
    val fuelCostPln = totalKm * max(0.0, goals.fuelCostPerKmPln)
    val netProfitPln = offer.grossFarePln - commissionPln - fuelCostPln
    val netPlnPerKm = netProfitPln / effectiveKm

    val fareBelowMin = offer.grossFarePln < goals.minFarePln
    val pickupTooFar = safePickup > goals.maxPickupKm
    val meetsTargetRate = grossPlnPerKm >= goals.targetPlnPerKm
    val meetsMinRate = grossPlnPerKm >= goals.minPlnPerKm

    val recommendation =
      when {
        !meetsMinRate -> Recommendation.REJECT
        fareBelowMin && !meetsTargetRate -> Recommendation.REJECT
        fareBelowMin -> Recommendation.BORDERLINE
        pickupTooFar && !meetsTargetRate -> Recommendation.REJECT
        pickupTooFar -> Recommendation.BORDERLINE
        meetsTargetRate -> Recommendation.ACCEPT
        else -> Recommendation.BORDERLINE
      }

    val delta = grossPlnPerKm - goals.targetPlnPerKm
    val formattedRate = formatPln(grossPlnPerKm)
    val formattedTarget = formatPln(goals.targetPlnPerKm)
    val formattedMin = formatPln(goals.minPlnPerKm)

    val headline =
      when (recommendation) {
        Recommendation.ACCEPT -> "ACCEPT • $formattedRate PLN/km"
        Recommendation.BORDERLINE -> "CAUTION • $formattedRate PLN/km"
        Recommendation.REJECT -> "REJECT • $formattedRate PLN/km"
      }

    val reason =
      when {
        !meetsMinRate ->
          "${formatPln(goals.minPlnPerKm - grossPlnPerKm)} PLN/km below your $formattedMin min"
        fareBelowMin ->
          "Fare ${formatPln(offer.grossFarePln)} PLN is below ${formatPln(goals.minFarePln)} PLN min"
        pickupTooFar ->
          "Pickup ${formatKm(safePickup)} km exceeds ${formatKm(goals.maxPickupKm)} km limit"
        meetsTargetRate ->
          "+${formatPln(delta)} PLN/km above your $formattedTarget PLN/km goal"
        else ->
          "${formatPln(-delta)} PLN/km under $formattedTarget goal (above $formattedMin min)"
      }

    val goalRatio =
      if (goals.targetPlnPerKm > 0.0) {
        (grossPlnPerKm / goals.targetPlnPerKm).toFloat().coerceIn(0f, 1.5f)
      } else {
        1f
      }

    return EvaluatedRide(
      offer = offer,
      effectiveKm = effectiveKm,
      totalKm = totalKm,
      grossPlnPerKm = grossPlnPerKm,
      commissionPln = commissionPln,
      fuelCostPln = fuelCostPln,
      netProfitPln = netProfitPln,
      netPlnPerKm = netPlnPerKm,
      recommendation = recommendation,
      headline = headline,
      reason = reason,
      goalRatio = goalRatio,
    )
  }

  fun formatPln(value: Double): String = String.format(Locale.US, "%.2f", value)

  fun formatKm(value: Double): String = String.format(Locale.US, "%.1f", value)
}
