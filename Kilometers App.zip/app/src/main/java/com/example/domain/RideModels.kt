package com.example.domain

enum class RidePlatform(val displayName: String, val badgeText: String) {
  BOLT("Bolt", "BOLT"),
  UBER("Uber", "UBER"),
  MANUAL("Quick Check", "CHECK"),
}

enum class Recommendation {
  ACCEPT,
  BORDERLINE,
  REJECT,
}

enum class DriverAction {
  PENDING,
  ACCEPTED,
  REJECTED,
  DISMISSED,
}

data class ProfitGoals(
  val targetPlnPerKm: Double = 3.20,
  val minPlnPerKm: Double = 2.40,
  val minFarePln: Double = 15.0,
  val maxPickupKm: Double = 3.5,
  val includePickupDistance: Boolean = true,
  val boltCommissionPercent: Double = 25.0,
  val uberCommissionPercent: Double = 25.0,
  val fuelCostPerKmPln: Double = 0.55,
  val autoHideSeconds: Int = 18,
  val overlayEnabled: Boolean = true,
)

data class IncomingRideOffer(
  val id: String,
  val platform: RidePlatform,
  val grossFarePln: Double,
  val pickupKm: Double,
  val tripKm: Double,
  val durationMinutes: Int? = null,
  val surgeMultiplier: Double? = null,
  val pickupLabel: String? = null,
  val detectedAtMillis: Long = System.currentTimeMillis(),
  val isSimulated: Boolean = false,
)

data class EvaluatedRide(
  val offer: IncomingRideOffer,
  val effectiveKm: Double,
  val totalKm: Double,
  val grossPlnPerKm: Double,
  val commissionPln: Double,
  val fuelCostPln: Double,
  val netProfitPln: Double,
  val netPlnPerKm: Double,
  val recommendation: Recommendation,
  val headline: String,
  val reason: String,
  val goalRatio: Float,
)
