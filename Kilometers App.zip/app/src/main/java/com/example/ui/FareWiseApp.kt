package com.example.ui

import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Brightness4
import androidx.compose.material.icons.filled.Brightness7
import androidx.compose.material.icons.filled.DirectionsCar
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material.icons.outlined.DirectionsCar
import androidx.compose.material.icons.outlined.History
import androidx.compose.material.icons.outlined.Tune
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationRail
import androidx.compose.material3.NavigationRailItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.example.R
import com.example.ui.screens.GoalsScreen
import com.example.ui.screens.HistoryScreen
import com.example.ui.screens.HudScreen

const val ROUTE_HUD = "hud"
const val ROUTE_GOALS = "goals"
const val ROUTE_HISTORY = "history"

private data class NavDestination(
  val route: String,
  val labelRes: Int,
  val selectedIcon: ImageVector,
  val unselectedIcon: ImageVector,
  val testTag: String,
)

private val Destinations =
  listOf(
    NavDestination(
      route = ROUTE_HUD,
      labelRes = R.string.nav_hud,
      selectedIcon = Icons.Filled.DirectionsCar,
      unselectedIcon = Icons.Outlined.DirectionsCar,
      testTag = "nav_hud",
    ),
    NavDestination(
      route = ROUTE_GOALS,
      labelRes = R.string.nav_goals,
      selectedIcon = Icons.Filled.Tune,
      unselectedIcon = Icons.Outlined.Tune,
      testTag = "nav_goals",
    ),
    NavDestination(
      route = ROUTE_HISTORY,
      labelRes = R.string.nav_history,
      selectedIcon = Icons.Filled.History,
      unselectedIcon = Icons.Outlined.History,
      testTag = "nav_history",
    ),
  )

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun FareWiseApp(viewModel: MainViewModel, modifier: Modifier = Modifier) {
  val navController = rememberNavController()
  val navBackStackEntry by navController.currentBackStackEntryAsState()
  val currentRoute = navBackStackEntry?.destination?.route ?: ROUTE_HUD

  val activeOffer by viewModel.activeOffer.collectAsStateWithLifecycle()
  val goals by viewModel.goals.collectAsStateWithLifecycle()
  val history by viewModel.history.collectAsStateWithLifecycle()
  val shiftSummary by viewModel.shiftSummary.collectAsStateWithLifecycle()
  val integrationStatus by viewModel.integrationStatus.collectAsStateWithLifecycle()
  val overlayServiceRunning by viewModel.overlayServiceRunning.collectAsStateWithLifecycle()
  val quickFare by viewModel.quickFareInput.collectAsStateWithLifecycle()
  val quickPickup by viewModel.quickPickupInput.collectAsStateWithLifecycle()
  val quickTrip by viewModel.quickTripInput.collectAsStateWithLifecycle()
  val quickPlatform by viewModel.quickPlatform.collectAsStateWithLifecycle()
  val quickError by viewModel.quickError.collectAsStateWithLifecycle()
  val darkMode by viewModel.darkCockpitMode.collectAsStateWithLifecycle()

  fun navigateTo(route: String) {
    navController.navigate(route) {
      popUpTo(navController.graph.findStartDestination().id) { saveState = true }
      launchSingleTop = true
      restoreState = true
    }
  }

  BoxWithConstraints(modifier = modifier.fillMaxSize()) {
    val useRail = maxWidth >= 600.dp

    Scaffold(
      contentWindowInsets = WindowInsets.safeDrawing,
      topBar = {
        TopAppBar(
          title = {
            Row {
              Text(
                text = stringResource(R.string.app_name),
                style = MaterialTheme.typography.titleLarge,
              )
              Text(
                text = " • PLN/km",
                style = MaterialTheme.typography.titleLarge,
                color = MaterialTheme.colorScheme.primary,
              )
            }
          },
          actions = {
            IconButton(
              onClick = { viewModel.toggleDarkCockpitMode() },
              modifier = Modifier.minimumInteractiveComponentSize().testTag("toggle_theme_button"),
            ) {
              Icon(
                imageVector = if (darkMode) Icons.Filled.Brightness7 else Icons.Filled.Brightness4,
                contentDescription = if (darkMode) "Switch to Daylight mode" else "Switch to Night Cockpit mode",
              )
            }
          },
          colors =
            TopAppBarDefaults.topAppBarColors(
              containerColor = MaterialTheme.colorScheme.background,
              titleContentColor = MaterialTheme.colorScheme.onBackground,
            ),
        )
      },
      bottomBar = {
        if (!useRail) {
          NavigationBar {
            Destinations.forEach { dest ->
              val selected = currentRoute == dest.route
              val label = stringResource(dest.labelRes)
              NavigationBarItem(
                selected = selected,
                onClick = { navigateTo(dest.route) },
                icon = {
                  Icon(
                    imageVector = if (selected) dest.selectedIcon else dest.unselectedIcon,
                    contentDescription = label,
                  )
                },
                label = { Text(label) },
                modifier = Modifier.testTag(dest.testTag),
              )
            }
          }
        }
      },
    ) { innerPadding ->
      Row(modifier = Modifier.fillMaxSize().padding(innerPadding)) {
        if (useRail) {
          NavigationRail {
            Destinations.forEach { dest ->
              val selected = currentRoute == dest.route
              val label = stringResource(dest.labelRes)
              NavigationRailItem(
                selected = selected,
                onClick = { navigateTo(dest.route) },
                icon = {
                  Icon(
                    imageVector = if (selected) dest.selectedIcon else dest.unselectedIcon,
                    contentDescription = label,
                  )
                },
                label = { Text(label) },
                modifier = Modifier.testTag(dest.testTag),
              )
            }
          }
        }

        NavHost(
          navController = navController,
          startDestination = ROUTE_HUD,
          modifier = Modifier.weight(1f).fillMaxSize(),
        ) {
          composable(ROUTE_HUD) {
            HudScreen(
              activeOffer = activeOffer,
              goals = goals,
              integrationStatus = integrationStatus,
              overlayServiceRunning = overlayServiceRunning,
              shiftSummary = shiftSummary,
              quickFareInput = quickFare,
              quickPickupInput = quickPickup,
              quickTripInput = quickTrip,
              quickPlatform = quickPlatform,
              quickError = quickError,
              onQuickFareChange = viewModel::onQuickFareChange,
              onQuickPickupChange = viewModel::onQuickPickupChange,
              onQuickTripChange = viewModel::onQuickTripChange,
              onQuickPlatformChange = viewModel::onQuickPlatformChange,
              onEvaluateManualOffer = viewModel::evaluateManualOffer,
              onTriggerSampleOffer = viewModel::triggerSampleOffer,
              onDriverAction = viewModel::recordActiveAction,
              onDismissActiveOffer = viewModel::dismissActiveOffer,
              onToggleOverlayService = viewModel::startOrStopOverlayService,
              onRefreshStatus = viewModel::refreshSystemStatus,
            )
          }

          composable(ROUTE_GOALS) {
            GoalsScreen(
              goals = goals,
              onUpdateGoals = viewModel::updateGoals,
            )
          }

          composable(ROUTE_HISTORY) {
            HistoryScreen(
              history = history,
              shiftSummary = shiftSummary,
              onDeleteItem = viewModel::deleteHistoryItem,
              onClearAll = viewModel::clearHistory,
            )
          }
        }
      }
    }
  }
}
