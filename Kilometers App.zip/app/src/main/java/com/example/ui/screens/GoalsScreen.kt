package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.LocalGasStation
import androidx.compose.material.icons.filled.Timer
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Slider
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.domain.IncomingRideOffer
import com.example.domain.ProfitGoals
import com.example.domain.Recommendation
import com.example.domain.RideDecisionEngine
import com.example.domain.RidePlatform
import com.example.ui.theme.AmberSignal
import com.example.ui.theme.CrimsonSignal
import com.example.ui.theme.ElectricCyan
import com.example.ui.theme.EmeraldSignal
import kotlin.math.roundToInt

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun GoalsScreen(
  goals: ProfitGoals,
  onUpdateGoals: ((ProfitGoals) -> ProfitGoals) -> Unit,
  modifier: Modifier = Modifier,
) {
  val samplePreview =
    remember(goals) {
      RideDecisionEngine.evaluate(
        IncomingRideOffer(
          id = "goal_preview",
          platform = RidePlatform.BOLT,
          grossFarePln = 30.0,
          pickupKm = 1.5,
          tripKm = 7.5,
          isSimulated = true,
        ),
        goals,
      )
    }

  val previewColor =
    when (samplePreview.recommendation) {
      Recommendation.ACCEPT -> EmeraldSignal
      Recommendation.BORDERLINE -> AmberSignal
      Recommendation.REJECT -> CrimsonSignal
    }

  Column(
    modifier = modifier.fillMaxSize().padding(horizontal = 16.dp),
    horizontalAlignment = Alignment.CenterHorizontally,
  ) {
    LazyColumn(
      modifier = Modifier.fillMaxSize().widthIn(max = 680.dp),
      verticalArrangement = Arrangement.spacedBy(12.dp),
      contentPadding = PaddingValues(top = 12.dp, bottom = 24.dp),
    ) {
      // Live Rule Preview Card
      item {
        Surface(
          shape = MaterialTheme.shapes.medium,
          color = MaterialTheme.colorScheme.surface,
          border = BorderStroke(1.5.dp, previewColor),
        ) {
          Column(modifier = Modifier.padding(14.dp)) {
            Text(
              text = "LIVE GOAL TEST: 30.00 PLN (1.5 km pickup + 7.5 km trip)",
              style = MaterialTheme.typography.labelSmall,
              color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
            Spacer(modifier = Modifier.height(4.dp))
            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.SpaceBetween,
              verticalAlignment = Alignment.CenterVertically,
            ) {
              Text(
                text = samplePreview.headline,
                style = MaterialTheme.typography.titleLarge,
                color = previewColor,
              )
              Text(
                text = "Net ${RideDecisionEngine.formatPln(samplePreview.netProfitPln)} PLN",
                style = MaterialTheme.typography.labelLarge,
                color = ElectricCyan,
              )
            }
            Spacer(modifier = Modifier.height(2.dp))
            Text(
              text = samplePreview.reason,
              style = MaterialTheme.typography.bodyMedium,
              color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
          }
        }
      }

      // Target PLN/km & Minimum PLN/km
      item {
        Card(
          colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
          border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline),
        ) {
          Column(modifier = Modifier.padding(16.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
              Icon(Icons.Filled.Tune, contentDescription = null, tint = EmeraldSignal)
              Spacer(modifier = Modifier.width(8.dp))
              Text("PLN/km Profit Thresholds", style = MaterialTheme.typography.titleMedium)
            }

            Spacer(modifier = Modifier.height(12.dp))

            GoalSliderRow(
              title = "Target Goal (Accept)",
              valueLabel = "${RideDecisionEngine.formatPln(goals.targetPlnPerKm)} PLN/km",
              value = goals.targetPlnPerKm.toFloat(),
              range = 1.8f..6.0f,
              steps = 41,
              testTag = "slider_target_pln_km",
              onValueChange = { v ->
                val rounded = ((v * 10f).roundToInt() / 10.0)
                onUpdateGoals {
                  it.copy(
                    targetPlnPerKm = rounded,
                    minPlnPerKm = it.minPlnPerKm.coerceAtMost(rounded),
                  )
                }
              },
            )

            FlowRow(
              horizontalArrangement = Arrangement.spacedBy(8.dp),
              verticalArrangement = Arrangement.spacedBy(4.dp),
            ) {
              listOf(2.50, 3.00, 3.20, 3.60, 4.00).forEach { preset ->
                FilterChip(
                  selected = kotlin.math.abs(goals.targetPlnPerKm - preset) < 0.05,
                  onClick = {
                    onUpdateGoals {
                      it.copy(
                        targetPlnPerKm = preset,
                        minPlnPerKm = it.minPlnPerKm.coerceAtMost(preset),
                      )
                    }
                  },
                  label = { Text("${RideDecisionEngine.formatPln(preset)} PLN") },
                  modifier = Modifier.minimumInteractiveComponentSize(),
                )
              }
            }

            Spacer(modifier = Modifier.height(12.dp))

            GoalSliderRow(
              title = "Minimum Acceptable (Below = Reject)",
              valueLabel = "${RideDecisionEngine.formatPln(goals.minPlnPerKm)} PLN/km",
              value = goals.minPlnPerKm.toFloat(),
              range = 1.2f..goals.targetPlnPerKm.toFloat(),
              steps = 30,
              testTag = "slider_min_pln_km",
              onValueChange = { v ->
                val rounded = ((v * 10f).roundToInt() / 10.0)
                onUpdateGoals { it.copy(minPlnPerKm = rounded) }
              },
            )

            Spacer(modifier = Modifier.height(10.dp))

            Row(
              modifier = Modifier.fillMaxWidth(),
              verticalAlignment = Alignment.CenterVertically,
            ) {
              Column(modifier = Modifier.weight(1f)) {
                Text(
                  text = "Include Pickup Distance in PLN/km",
                  style = MaterialTheme.typography.bodyLarge,
                  fontWeight = FontWeight.Medium,
                )
                Text(
                  text = "Recommended in Poland: divides fare by (pickup + trip) km",
                  style = MaterialTheme.typography.bodyMedium,
                  color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
              }
              Switch(
                checked = goals.includePickupDistance,
                onCheckedChange = { checked ->
                  onUpdateGoals { it.copy(includePickupDistance = checked) }
                },
                modifier = Modifier.testTag("switch_include_pickup"),
              )
            }
          }
        }
      }

      // Trip Filters (Min Fare & Max Pickup)
      item {
        Card(
          colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
          border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline),
        ) {
          Column(modifier = Modifier.padding(16.dp)) {
            Text("Trip Filters", style = MaterialTheme.typography.titleMedium)
            Spacer(modifier = Modifier.height(12.dp))

            GoalSliderRow(
              title = "Minimum Fare",
              valueLabel = "${RideDecisionEngine.formatPln(goals.minFarePln)} PLN",
              value = goals.minFarePln.toFloat(),
              range = 8f..40f,
              steps = 31,
              testTag = "slider_min_fare",
              onValueChange = { v ->
                onUpdateGoals { it.copy(minFarePln = v.roundToInt().toDouble()) }
              },
            )

            Spacer(modifier = Modifier.height(12.dp))

            GoalSliderRow(
              title = "Max Pickup Distance",
              valueLabel = "${RideDecisionEngine.formatKm(goals.maxPickupKm)} km",
              value = goals.maxPickupKm.toFloat(),
              range = 1.0f..10.0f,
              steps = 17,
              testTag = "slider_max_pickup",
              onValueChange = { v ->
                val rounded = ((v * 2f).roundToInt() / 2.0)
                onUpdateGoals { it.copy(maxPickupKm = rounded) }
              },
            )
          }
        }
      }

      // Commission & Fuel Costs
      item {
        Card(
          colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
          border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline),
        ) {
          Column(modifier = Modifier.padding(16.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
              Icon(Icons.Filled.LocalGasStation, contentDescription = null, tint = ElectricCyan)
              Spacer(modifier = Modifier.width(8.dp))
              Text("Poland Net Profit Costs", style = MaterialTheme.typography.titleMedium)
            }
            Spacer(modifier = Modifier.height(12.dp))

            GoalSliderRow(
              title = "Bolt Commission",
              valueLabel = "${goals.boltCommissionPercent.roundToInt()}%",
              value = goals.boltCommissionPercent.toFloat(),
              range = 0f..40f,
              steps = 39,
              testTag = "slider_bolt_commission",
              onValueChange = { v ->
                onUpdateGoals { it.copy(boltCommissionPercent = v.roundToInt().toDouble()) }
              },
            )

            Spacer(modifier = Modifier.height(10.dp))

            GoalSliderRow(
              title = "Uber Commission",
              valueLabel = "${goals.uberCommissionPercent.roundToInt()}%",
              value = goals.uberCommissionPercent.toFloat(),
              range = 0f..40f,
              steps = 39,
              testTag = "slider_uber_commission",
              onValueChange = { v ->
                onUpdateGoals { it.copy(uberCommissionPercent = v.roundToInt().toDouble()) }
              },
            )

            Spacer(modifier = Modifier.height(10.dp))

            GoalSliderRow(
              title = "Fuel / Car Wear Cost",
              valueLabel = "${RideDecisionEngine.formatPln(goals.fuelCostPerKmPln)} PLN/km",
              value = goals.fuelCostPerKmPln.toFloat(),
              range = 0.1f..2.0f,
              steps = 37,
              testTag = "slider_fuel_cost",
              onValueChange = { v ->
                val rounded = ((v * 20f).roundToInt() / 20.0)
                onUpdateGoals { it.copy(fuelCostPerKmPln = rounded) }
              },
            )
          }
        }
      }

      // Top Box Timer
      item {
        Card(
          colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
          border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline),
        ) {
          Column(modifier = Modifier.padding(16.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
              Icon(Icons.Filled.Timer, contentDescription = null, tint = AmberSignal)
              Spacer(modifier = Modifier.width(8.dp))
              Text("Top Overlay Behavior", style = MaterialTheme.typography.titleMedium)
            }
            Spacer(modifier = Modifier.height(12.dp))

            GoalSliderRow(
              title = "Auto-Hide Top Box After",
              valueLabel = "${goals.autoHideSeconds}s",
              value = goals.autoHideSeconds.toFloat(),
              range = 6f..45f,
              steps = 38,
              testTag = "slider_auto_hide",
              onValueChange = { v ->
                onUpdateGoals { it.copy(autoHideSeconds = v.roundToInt()) }
              },
            )
          }
        }
      }
    }
  }
}

@Composable
private fun GoalSliderRow(
  title: String,
  valueLabel: String,
  value: Float,
  range: ClosedFloatingPointRange<Float>,
  steps: Int,
  testTag: String,
  onValueChange: (Float) -> Unit,
) {
  Column(modifier = Modifier.fillMaxWidth()) {
    Row(
      modifier = Modifier.fillMaxWidth(),
      horizontalArrangement = Arrangement.SpaceBetween,
      verticalAlignment = Alignment.CenterVertically,
    ) {
      Text(text = title, style = MaterialTheme.typography.bodyLarge)
      Text(
        text = valueLabel,
        style = MaterialTheme.typography.labelLarge,
        color = MaterialTheme.colorScheme.primary,
      )
    }
    Slider(
      value = value.coerceIn(range.start, range.endInclusive),
      onValueChange = onValueChange,
      valueRange = range,
      steps = steps,
      modifier = Modifier.testTag(testTag),
    )
  }
}
