package com.example.ui.components

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.size
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.unit.dp
import com.example.domain.RideDecisionEngine
import com.example.ui.theme.AmberSignal
import com.example.ui.theme.CrimsonSignal
import com.example.ui.theme.EmeraldSignal
import kotlin.math.cos
import kotlin.math.sin

@Composable
fun ProfitGauge(
  currentPlnPerKm: Double,
  minPlnPerKm: Double,
  targetPlnPerKm: Double,
  modifier: Modifier = Modifier,
) {
  val maxScale = (targetPlnPerKm * 1.6).coerceAtLeast(5.0)
  val targetRatio = (currentPlnPerKm / maxScale).toFloat().coerceIn(0f, 1f)
  val animatedRatio by
    animateFloatAsState(
      targetValue = targetRatio,
      animationSpec = spring(),
      label = "gauge_sweep",
    )

  val activeColor =
    when {
      currentPlnPerKm <= 0.0 -> MaterialTheme.colorScheme.onSurfaceVariant
      currentPlnPerKm >= targetPlnPerKm -> EmeraldSignal
      currentPlnPerKm >= minPlnPerKm -> AmberSignal
      else -> CrimsonSignal
    }
  val trackColor = MaterialTheme.colorScheme.surfaceVariant

  Box(modifier = modifier.size(132.dp), contentAlignment = Alignment.Center) {
    Canvas(modifier = Modifier.fillMaxSize()) {
      val strokeWidth = 12.dp.toPx()
      val pad = strokeWidth / 2f + 4.dp.toPx()
      val arcSize = Size(size.width - pad * 2f, size.height - pad * 2f)
      val topLeft = Offset(pad, pad)

      // Background track (150 deg to 390 deg = 240 deg sweep)
      drawArc(
        color = trackColor,
        startAngle = 150f,
        sweepAngle = 240f,
        useCenter = false,
        topLeft = topLeft,
        size = arcSize,
        style = Stroke(width = strokeWidth, cap = StrokeCap.Round),
      )

      // Active value arc
      if (animatedRatio > 0.01f) {
        drawArc(
          color = activeColor,
          startAngle = 150f,
          sweepAngle = 240f * animatedRatio,
          useCenter = false,
          topLeft = topLeft,
          size = arcSize,
          style = Stroke(width = strokeWidth, cap = StrokeCap.Round),
        )
      }

      // Target marker tick
      val goalFraction = (targetPlnPerKm / maxScale).toFloat().coerceIn(0.05f, 0.95f)
      val goalAngleRad = Math.toRadians((150f + 240f * goalFraction).toDouble())
      val radius = arcSize.width / 2f
      val center = Offset(size.width / 2f, size.height / 2f)
      val innerPt =
        Offset(
          x = center.x + (radius - 10.dp.toPx()) * cos(goalAngleRad).toFloat(),
          y = center.y + (radius - 10.dp.toPx()) * sin(goalAngleRad).toFloat(),
        )
      val outerPt =
        Offset(
          x = center.x + (radius + 6.dp.toPx()) * cos(goalAngleRad).toFloat(),
          y = center.y + (radius + 6.dp.toPx()) * sin(goalAngleRad).toFloat(),
        )
      drawLine(
        color = EmeraldSignal,
        start = innerPt,
        end = outerPt,
        strokeWidth = 3.dp.toPx(),
        cap = StrokeCap.Round,
      )
    }

    Column(horizontalAlignment = Alignment.CenterHorizontally) {
      Text(
        text =
          if (currentPlnPerKm > 0.0) RideDecisionEngine.formatPln(currentPlnPerKm) else "--",
        style = MaterialTheme.typography.headlineMedium,
        color = activeColor,
      )
      Text(
        text = "PLN/km",
        style = MaterialTheme.typography.labelSmall,
        color = MaterialTheme.colorScheme.onSurfaceVariant,
      )
    }
  }
}
