package com.example.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp

private val CockpitDarkColorScheme =
  darkColorScheme(
    primary = EmeraldSignal,
    onPrimary = EmeraldDarkText,
    primaryContainer = EmeraldTint,
    onPrimaryContainer = EmeraldSignal,
    secondary = ElectricCyan,
    onSecondary = CyanDarkText,
    secondaryContainer = Color(0xFF113044),
    onSecondaryContainer = ElectricCyan,
    tertiary = AmberSignal,
    onTertiary = AmberDarkText,
    tertiaryContainer = AmberTint,
    onTertiaryContainer = AmberSignal,
    error = CrimsonSignal,
    onError = Color.White,
    errorContainer = CrimsonTint,
    onErrorContainer = Color(0xFFFF8A95),
    background = AsphaltBg,
    onBackground = TextPrimaryDark,
    surface = CarbonSurface,
    onSurface = TextPrimaryDark,
    surfaceVariant = InstrumentSurface,
    onSurfaceVariant = TextSecondaryDark,
    outline = InstrumentOutline,
  )

private val DaylightLightColorScheme =
  lightColorScheme(
    primary = Color(0xFF008A4B),
    onPrimary = Color.White,
    primaryContainer = Color(0xFFD1FAE5),
    onPrimaryContainer = Color(0xFF064E3B),
    secondary = Color(0xFF0284C7),
    onSecondary = Color.White,
    secondaryContainer = Color(0xFFE0F2FE),
    onSecondaryContainer = Color(0xFF0C4A6E),
    tertiary = Color(0xFFD97706),
    onTertiary = Color.White,
    tertiaryContainer = Color(0xFFFEF3C7),
    onTertiaryContainer = Color(0xFF78350F),
    error = Color(0xFFDC2626),
    onError = Color.White,
    errorContainer = Color(0xFFFEE2E2),
    onErrorContainer = Color(0xFF7F1D1D),
    background = DaylightBg,
    onBackground = TextPrimaryLight,
    surface = DaylightSurface,
    onSurface = TextPrimaryLight,
    surfaceVariant = DaylightVariant,
    onSurfaceVariant = TextSecondaryLight,
    outline = DaylightOutline,
  )

private val AppShapes =
  Shapes(
    small = RoundedCornerShape(10.dp),
    medium = RoundedCornerShape(16.dp),
    large = RoundedCornerShape(22.dp),
  )

@Composable
fun FareWiseTheme(
  darkTheme: Boolean = isSystemInDarkTheme(),
  content: @Composable () -> Unit,
) {
  val colorScheme = if (darkTheme) CockpitDarkColorScheme else DaylightLightColorScheme

  MaterialTheme(
    colorScheme = colorScheme,
    typography = AppTypography,
    shapes = AppShapes,
    content = content,
  )
}
