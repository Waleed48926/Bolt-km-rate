package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Cockpit Dark Surfaces
val AsphaltBg = Color(0xFF0B0F14)
val CarbonSurface = Color(0xFF131A22)
val InstrumentSurface = Color(0xFF1B2430)
val InstrumentOutline = Color(0xFF2B3748)

// Daylight Surfaces
val DaylightBg = Color(0xFFF3F6FA)
val DaylightSurface = Color(0xFFFFFFFF)
val DaylightVariant = Color(0xFFE6ECF3)
val DaylightOutline = Color(0xFFC9D4E2)

// Signal & Brand Telemetry Colors
val EmeraldSignal = Color(0xFF10E584)
val EmeraldDarkText = Color(0xFF042917)
val EmeraldTint = Color(0xFF133827)

val AmberSignal = Color(0xFFFFB020)
val AmberDarkText = Color(0xFF291A00)
val AmberTint = Color(0xFF3A2A0D)

val CrimsonSignal = Color(0xFFFF4757)
val CrimsonTint = Color(0xFF3E161D)

val ElectricCyan = Color(0xFF38BDF8)
val CyanDarkText = Color(0xFF042233)

val BoltAccent = Color(0xFF34D399)
val BoltContainer = Color(0xFF123626)
val UberAccent = Color(0xFFE2E8F0)
val UberContainer = Color(0xFF1E293B)

val TextPrimaryDark = Color(0xFFF8FAFC)
val TextSecondaryDark = Color(0xFF94A3B8)
val TextPrimaryLight = Color(0xFF0F172A)
val TextSecondaryLight = Color(0xFF475569)
