package com.example.ui.components

import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.domain.RidePlatform
import com.example.ui.theme.BoltAccent
import com.example.ui.theme.BoltContainer
import com.example.ui.theme.UberAccent
import com.example.ui.theme.UberContainer

@Composable
fun PlatformChip(platform: RidePlatform, modifier: Modifier = Modifier) {
  val bg =
    when (platform) {
      RidePlatform.BOLT -> BoltContainer
      RidePlatform.UBER -> UberContainer
      RidePlatform.MANUAL -> MaterialTheme.colorScheme.secondaryContainer
    }
  val fg =
    when (platform) {
      RidePlatform.BOLT -> BoltAccent
      RidePlatform.UBER -> UberAccent
      RidePlatform.MANUAL -> MaterialTheme.colorScheme.onSecondaryContainer
    }
  Surface(
    color = bg,
    shape = RoundedCornerShape(8.dp),
    modifier = modifier,
  ) {
    Text(
      text = platform.badgeText,
      style = MaterialTheme.typography.labelSmall,
      fontWeight = FontWeight.Bold,
      color = fg,
      modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
    )
  }
}
