package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.DeleteSweep
import androidx.compose.material.icons.filled.History
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.example.R
import com.example.data.RideEvaluationEntity
import com.example.domain.DriverAction
import com.example.domain.Recommendation
import com.example.domain.RideDecisionEngine
import com.example.domain.RidePlatform
import com.example.ui.ShiftSummary
import com.example.ui.components.PlatformChip
import com.example.ui.theme.AmberSignal
import com.example.ui.theme.CrimsonSignal
import com.example.ui.theme.ElectricCyan
import com.example.ui.theme.EmeraldSignal
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private enum class HistoryFilter(val label: String) {
  ALL("All"),
  ACCEPT_REC("Goal Met"),
  REJECT_REC("Rejected"),
  BOLT("Bolt"),
  UBER("Uber"),
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun HistoryScreen(
  history: List<RideEvaluationEntity>,
  shiftSummary: ShiftSummary,
  onDeleteItem: (String) -> Unit,
  onClearAll: () -> Unit,
  modifier: Modifier = Modifier,
) {
  var selectedFilter by remember { mutableStateOf(HistoryFilter.ALL) }
  var showClearDialog by remember { mutableStateOf(false) }

  val filteredHistory =
    remember(history, selectedFilter) {
      when (selectedFilter) {
        HistoryFilter.ALL -> history
        HistoryFilter.ACCEPT_REC ->
          history.filter { it.recommendation == Recommendation.ACCEPT.name }
        HistoryFilter.REJECT_REC ->
          history.filter {
            it.recommendation == Recommendation.REJECT.name ||
              it.driverAction == DriverAction.REJECTED.name
          }
        HistoryFilter.BOLT -> history.filter { it.platform == RidePlatform.BOLT.name }
        HistoryFilter.UBER -> history.filter { it.platform == RidePlatform.UBER.name }
      }
    }

  if (showClearDialog) {
    AlertDialog(
      onDismissRequest = { showClearDialog = false },
      title = { Text("Clear Shift Log?") },
      text = { Text("This removes all logged ride evaluations from this device.") },
      confirmButton = {
        TextButton(
          onClick = {
            onClearAll()
            showClearDialog = false
          },
          modifier = Modifier.testTag("confirm_clear_history_button"),
        ) {
          Text("Clear", color = CrimsonSignal)
        }
      },
      dismissButton = {
        TextButton(onClick = { showClearDialog = false }) { Text("Cancel") }
      },
    )
  }

  Column(
    modifier = modifier.fillMaxSize().padding(horizontal = 16.dp),
    horizontalAlignment = Alignment.CenterHorizontally,
  ) {
    Column(modifier = Modifier.fillMaxWidth().widthIn(max = 680.dp)) {
      Spacer(modifier = Modifier.height(10.dp))

      // Summary Row
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(8.dp),
      ) {
        SummaryMetricTile(
          label = "Offers",
          value = "${shiftSummary.totalOffers}",
          modifier = Modifier.weight(1f),
        )
        SummaryMetricTile(
          label = "Avg PLN/km",
          value =
            if (shiftSummary.totalOffers > 0) {
              RideDecisionEngine.formatPln(shiftSummary.averagePlnPerKm)
            } else {
              "--"
            },
          modifier = Modifier.weight(1f),
        )
        SummaryMetricTile(
          label = "Accepted Net",
          value = "${RideDecisionEngine.formatPln(shiftSummary.estimatedAcceptedNetPln)} zł",
          modifier = Modifier.weight(1.1f),
        )
      }

      Spacer(modifier = Modifier.height(10.dp))

      Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically,
      ) {
        FlowRow(
          modifier = Modifier.weight(1f),
          horizontalArrangement = Arrangement.spacedBy(6.dp),
          verticalArrangement = Arrangement.spacedBy(4.dp),
        ) {
          HistoryFilter.entries.forEach { filter ->
            FilterChip(
              selected = selectedFilter == filter,
              onClick = { selectedFilter = filter },
              label = { Text(filter.label) },
              modifier = Modifier.minimumInteractiveComponentSize(),
            )
          }
        }

        if (history.isNotEmpty()) {
          IconButton(
            onClick = { showClearDialog = true },
            modifier = Modifier.minimumInteractiveComponentSize().testTag("clear_history_button"),
          ) {
            Icon(
              imageVector = Icons.Filled.DeleteSweep,
              contentDescription = "Clear shift log",
              tint = MaterialTheme.colorScheme.onSurfaceVariant,
            )
          }
        }
      }

      Spacer(modifier = Modifier.height(8.dp))

      if (filteredHistory.isEmpty()) {
        Box(
          modifier = Modifier.fillMaxSize().padding(24.dp),
          contentAlignment = Alignment.Center,
        ) {
          Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Icon(
              imageVector = Icons.Filled.History,
              contentDescription = null,
              tint = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.6f),
              modifier = Modifier.size(56.dp),
            )
            Spacer(modifier = Modifier.height(12.dp))
            Text(
              text = stringResource(R.string.history_empty_title),
              style = MaterialTheme.typography.titleLarge,
              textAlign = TextAlign.Center,
            )
            Spacer(modifier = Modifier.height(6.dp))
            Text(
              text = stringResource(R.string.history_empty_subtitle),
              style = MaterialTheme.typography.bodyMedium,
              color = MaterialTheme.colorScheme.onSurfaceVariant,
              textAlign = TextAlign.Center,
            )
          }
        }
      } else {
        LazyColumn(
          verticalArrangement = Arrangement.spacedBy(10.dp),
          contentPadding = PaddingValues(bottom = 24.dp),
        ) {
          items(filteredHistory, key = { it.id }) { item ->
            HistoryOfferCard(item = item, onDelete = { onDeleteItem(item.id) })
          }
        }
      }
    }
  }
}

@Composable
private fun SummaryMetricTile(label: String, value: String, modifier: Modifier = Modifier) {
  Surface(
    modifier = modifier,
    shape = RoundedCornerShape(12.dp),
    color = MaterialTheme.colorScheme.surface,
    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline),
  ) {
    Column(modifier = Modifier.padding(horizontal = 12.dp, vertical = 10.dp)) {
      Text(
        text = label,
        style = MaterialTheme.typography.labelSmall,
        color = MaterialTheme.colorScheme.onSurfaceVariant,
      )
      Spacer(modifier = Modifier.height(2.dp))
      Text(
        text = value,
        style = MaterialTheme.typography.titleLarge,
        color = MaterialTheme.colorScheme.onSurface,
      )
    }
  }
}

@Composable
private fun HistoryOfferCard(item: RideEvaluationEntity, onDelete: () -> Unit) {
  val signalColor =
    when (item.recommendationEnum()) {
      Recommendation.ACCEPT -> EmeraldSignal
      Recommendation.BORDERLINE -> AmberSignal
      Recommendation.REJECT -> CrimsonSignal
    }
  val timeFormat = remember { SimpleDateFormat("HH:mm", Locale.getDefault()) }
  val formattedTime = timeFormat.format(Date(item.timestampMillis))

  Card(
    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline),
  ) {
    Row(modifier = Modifier.fillMaxWidth()) {
      Box(modifier = Modifier.width(6.dp).height(104.dp).background(signalColor))
      Column(modifier = Modifier.weight(1f).padding(12.dp)) {
        Row(
          modifier = Modifier.fillMaxWidth(),
          verticalAlignment = Alignment.CenterVertically,
        ) {
          PlatformChip(platform = item.platformEnum())
          Spacer(modifier = Modifier.width(8.dp))
          Text(
            text = "${RideDecisionEngine.formatPln(item.grossPlnPerKm)} PLN/km",
            style = MaterialTheme.typography.titleMedium,
            color = signalColor,
          )
          Spacer(modifier = Modifier.weight(1f))
          Text(
            text = formattedTime,
            style = MaterialTheme.typography.labelSmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
          )
          IconButton(
            onClick = onDelete,
            modifier = Modifier.minimumInteractiveComponentSize(),
          ) {
            Icon(
              imageVector = Icons.Filled.Delete,
              contentDescription = "Delete ride log entry",
              tint = MaterialTheme.colorScheme.onSurfaceVariant,
              modifier = Modifier.size(18.dp),
            )
          }
        }

        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
        ) {
          Text(
            text =
              "${RideDecisionEngine.formatPln(item.grossFarePln)} PLN • ${RideDecisionEngine.formatKm(item.totalKm)} km",
            style = MaterialTheme.typography.bodyLarge,
          )
          Text(
            text = "Net ${RideDecisionEngine.formatPln(item.netProfitPln)} PLN",
            style = MaterialTheme.typography.bodyMedium,
            color = ElectricCyan,
          )
        }

        Spacer(modifier = Modifier.height(4.dp))

        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically,
        ) {
          Text(
            text = item.reason,
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.weight(1f),
          )
          if (item.driverActionEnum() != DriverAction.PENDING) {
            Spacer(modifier = Modifier.width(8.dp))
            Surface(
              shape = RoundedCornerShape(6.dp),
              color = MaterialTheme.colorScheme.surfaceVariant,
            ) {
              Text(
                text = item.driverActionEnum().name,
                style = MaterialTheme.typography.labelSmall,
                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp),
              )
            }
          }
        }
      }
    }
  }
}
