package com.example.ui.components

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import com.example.domain.EvaluatedRide
import com.example.domain.Recommendation
import com.example.domain.RideDecisionEngine
import com.example.ui.theme.AmberSignal
import com.example.ui.theme.CrimsonSignal
import com.example.ui.theme.EmeraldSignal
import kotlin.math.roundToInt

private val TaxiGold = Color(0xFFEAB308)
private val TaxiBoxBg = Color(0xEB16181D)

@Composable
fun MovablePlnPerKmBox(
  activeOffer: EvaluatedRide?,
  containerSize: IntSize,
  onDismiss: () -> Unit,
  modifier: Modifier = Modifier,
) {
  var offsetX by remember { mutableFloatStateOf(0f) }
  var offsetY by remember { mutableFloatStateOf(0f) }
  var boxSize by remember { mutableFloatStateOf(0f) }
  var boxHeight by remember { mutableFloatStateOf(0f) }

  val signalColor =
    when (activeOffer?.recommendation) {
      Recommendation.ACCEPT -> EmeraldSignal
      Recommendation.BORDERLINE -> AmberSignal
      Recommendation.REJECT -> CrimsonSignal
      null -> Color(0xFFCBD5E1)
    }

  val rateText =
    if (activeOffer != null) {
      RideDecisionEngine.formatPln(activeOffer.grossPlnPerKm)
    } else {
      "--.--"
    }

  val rootTag =
    if (activeOffer != null) "top_decision_box_active" else "top_decision_box_standby"

  Surface(
    modifier =
      modifier
        .offset { IntOffset(offsetX.roundToInt(), offsetY.roundToInt()) }
        .onSizeChanged {
          boxSize = it.width.toFloat()
          boxHeight = it.height.toFloat()
        }
        .pointerInput(containerSize) {
          detectDragGestures { change, dragAmount ->
            change.consume()
            val maxX = (containerSize.width - boxSize).coerceAtLeast(0f)
            val maxY = (containerSize.height - boxHeight).coerceAtLeast(0f)
            offsetX = (offsetX + dragAmount.x).coerceIn(0f, maxX)
            offsetY = (offsetY + dragAmount.y).coerceIn(0f, maxY)
          }
        }
        .testTag(rootTag),
    shape = RoundedCornerShape(10.dp),
    color = TaxiBoxBg,
    tonalElevation = 6.dp,
    shadowElevation = 10.dp,
    border = BorderStroke(1.5.dp, TaxiGold),
  ) {
    Column(modifier = Modifier.width(172.dp)) {
      TaxiCheckerStrip(modifier = Modifier.fillMaxWidth().height(5.dp))

      Row(
        modifier = Modifier.fillMaxWidth().padding(start = 12.dp, end = 4.dp, top = 6.dp, bottom = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
      ) {
        Row(
          modifier = Modifier.weight(1f),
          verticalAlignment = Alignment.Bottom,
        ) {
          Text(
            text = rateText,
            style = MaterialTheme.typography.headlineSmall,
            fontWeight = FontWeight.Bold,
            color = signalColor,
            modifier = Modifier.testTag("top_box_pln_per_km"),
          )
          Spacer(modifier = Modifier.width(4.dp))
          Text(
            text = "PLN/km",
            style = MaterialTheme.typography.labelSmall,
            fontWeight = FontWeight.Bold,
            color = signalColor.copy(alpha = 0.9f),
            modifier = Modifier.padding(bottom = 3.dp),
          )
        }

        if (activeOffer != null) {
          IconButton(
            onClick = onDismiss,
            modifier = Modifier.size(32.dp).testTag("top_box_dismiss_button"),
          ) {
            Icon(
              imageVector = Icons.Filled.Close,
              contentDescription = "Close PLN/km box",
              tint = Color(0xFF94A3B8),
              modifier = Modifier.size(16.dp),
            )
          }
        }
      }
    }
  }
}

@Composable
private fun TaxiCheckerStrip(modifier: Modifier = Modifier) {
  Canvas(modifier = modifier) {
    val cell = size.height.coerceAtLeast(4f)
    var x = 0f
    var index = 0
    while (x < size.width) {
      drawRect(
        color = if (index % 2 == 0) TaxiGold else Color(0xFF111318),
        topLeft = Offset(x, 0f),
        size = Size(cell, size.height),
      )
      x += cell
      index++
    }
  }
}
