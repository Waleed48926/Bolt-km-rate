package com.example.ui

import android.app.Application
import android.provider.Settings
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.FareWiseApplication
import com.example.data.RideEvaluationEntity
import com.example.domain.DriverAction
import com.example.domain.EvaluatedRide
import com.example.domain.IncomingRideOffer
import com.example.domain.ProfitGoals
import com.example.domain.Recommendation
import com.example.domain.RidePlatform
import com.example.domain.RideTextParser
import com.example.service.ServiceStatusHelper
import com.example.service.SystemIntegrationStatus
import com.example.service.TopOverlayService
import java.util.UUID
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

data class ShiftSummary(
  val totalOffers: Int = 0,
  val acceptedCount: Int = 0,
  val acceptRecommendedCount: Int = 0,
  val averagePlnPerKm: Double = 0.0,
  val estimatedAcceptedNetPln: Double = 0.0,
)

class MainViewModel(application: Application) : AndroidViewModel(application) {

  private val app = application as FareWiseApplication
  private val repository = app.repository

  val goals: StateFlow<ProfitGoals> =
    repository.goalsFlow.stateIn(
      scope = viewModelScope,
      started = SharingStarted.WhileSubscribed(5_000),
      initialValue = ProfitGoals(),
    )

  val activeOffer: StateFlow<EvaluatedRide?> = repository.activeEvaluatedRide

  val history: StateFlow<List<RideEvaluationEntity>> =
    repository.evaluationsFlow.stateIn(
      scope = viewModelScope,
      started = SharingStarted.WhileSubscribed(5_000),
      initialValue = emptyList(),
    )

  val overlayServiceRunning: StateFlow<Boolean> = TopOverlayService.isRunning

  val shiftSummary: StateFlow<ShiftSummary> =
    repository.evaluationsFlow
      .combine(goals) { list, _ ->
        if (list.isEmpty()) {
          ShiftSummary()
        } else {
          val accepted = list.filter { it.driverAction == DriverAction.ACCEPTED.name }
          val avgRate = list.map { it.grossPlnPerKm }.average()
          val acceptRec = list.count { it.recommendation == Recommendation.ACCEPT.name }
          ShiftSummary(
            totalOffers = list.size,
            acceptedCount = accepted.size,
            acceptRecommendedCount = acceptRec,
            averagePlnPerKm = avgRate,
            estimatedAcceptedNetPln = accepted.sumOf { it.netProfitPln },
          )
        }
      }
      .stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5_000),
        initialValue = ShiftSummary(),
      )

  private val _integrationStatus = MutableStateFlow(ServiceStatusHelper.getStatus(application))
  val integrationStatus: StateFlow<SystemIntegrationStatus> = _integrationStatus.asStateFlow()

  private val _quickFareInput = MutableStateFlow("36.50")
  val quickFareInput: StateFlow<String> = _quickFareInput.asStateFlow()

  private val _quickPickupInput = MutableStateFlow("1.2")
  val quickPickupInput: StateFlow<String> = _quickPickupInput.asStateFlow()

  private val _quickTripInput = MutableStateFlow("8.5")
  val quickTripInput: StateFlow<String> = _quickTripInput.asStateFlow()

  private val _quickPlatform = MutableStateFlow(RidePlatform.BOLT)
  val quickPlatform: StateFlow<RidePlatform> = _quickPlatform.asStateFlow()

  private val _quickError = MutableStateFlow<String?>(null)
  val quickError: StateFlow<String?> = _quickError.asStateFlow()

  private val _darkCockpitMode = MutableStateFlow(true)
  val darkCockpitMode: StateFlow<Boolean> = _darkCockpitMode.asStateFlow()

  fun refreshSystemStatus() {
    _integrationStatus.value = ServiceStatusHelper.getStatus(getApplication())
  }

  fun toggleDarkCockpitMode() {
    _darkCockpitMode.value = !_darkCockpitMode.value
  }

  fun onQuickFareChange(value: String) {
    _quickFareInput.value = value
    _quickError.value = null
  }

  fun onQuickPickupChange(value: String) {
    _quickPickupInput.value = value
    _quickError.value = null
  }

  fun onQuickTripChange(value: String) {
    _quickTripInput.value = value
    _quickError.value = null
  }

  fun onQuickPlatformChange(platform: RidePlatform) {
    _quickPlatform.value = platform
  }

  fun evaluateManualOffer() {
    val fare = _quickFareInput.value.trim().replace(',', '.').toDoubleOrNull()
    val pickup = _quickPickupInput.value.trim().replace(',', '.').toDoubleOrNull() ?: 0.0
    val trip = _quickTripInput.value.trim().replace(',', '.').toDoubleOrNull()
    if (fare == null || fare <= 0.0 || trip == null || trip <= 0.0 || pickup < 0.0) {
      _quickError.value = "Enter a valid fare in PLN and trip distance in km."
      return
    }
    submitAndTriggerOverlay(
      IncomingRideOffer(
        id = UUID.randomUUID().toString(),
        platform = _quickPlatform.value,
        grossFarePln = fare,
        pickupKm = pickup,
        tripKm = trip,
        isSimulated = false,
      )
    )
  }

  fun parseAndEvaluateClipboardText(rawText: String): Boolean {
    val parsed = RideTextParser.parse(rawText, isSimulated = false) ?: return false
    submitAndTriggerOverlay(parsed)
    return true
  }

  fun triggerSampleOffer(
    platform: RidePlatform,
    farePln: Double,
    pickupKm: Double,
    tripKm: Double,
    durationMinutes: Int,
  ) {
    submitAndTriggerOverlay(
      IncomingRideOffer(
        id = UUID.randomUUID().toString(),
        platform = platform,
        grossFarePln = farePln,
        pickupKm = pickupKm,
        tripKm = tripKm,
        durationMinutes = durationMinutes,
        isSimulated = true,
      )
    )
  }

  private fun submitAndTriggerOverlay(offer: IncomingRideOffer) {
    viewModelScope.launch {
      repository.submitOffer(offer, deduplicate = false)
      val ctx = getApplication<Application>()
      if (goals.value.overlayEnabled && Settings.canDrawOverlays(ctx)) {
        TopOverlayService.start(ctx)
      }
    }
  }

  fun recordActiveAction(action: DriverAction) {
    repository.recordActiveDriverAction(action)
  }

  fun dismissActiveOffer() {
    repository.dismissActiveOffer()
  }

  fun startOrStopOverlayService(enable: Boolean) {
    val ctx = getApplication<Application>()
    viewModelScope.launch {
      repository.updateGoals { it.copy(overlayEnabled = enable) }
      if (enable && Settings.canDrawOverlays(ctx)) {
        TopOverlayService.start(ctx)
      } else {
        TopOverlayService.stop(ctx)
      }
    }
  }

  fun updateGoals(transform: (ProfitGoals) -> ProfitGoals) {
    viewModelScope.launch { repository.updateGoals(transform) }
  }

  fun deleteHistoryItem(id: String) {
    viewModelScope.launch { repository.deleteEvaluation(id) }
  }

  fun clearHistory() {
    viewModelScope.launch { repository.clearHistory() }
  }
}
