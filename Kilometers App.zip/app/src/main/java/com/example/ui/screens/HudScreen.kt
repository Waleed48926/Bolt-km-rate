package com.example.ui.screens

import android.Manifest
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccessibilityNew
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.Calculate
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Layers
import androidx.compose.material.icons.filled.NotificationsActive
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.outlined.RadioButtonUnchecked
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import com.example.domain.DriverAction
import com.example.domain.EvaluatedRide
import com.example.domain.ProfitGoals
import com.example.domain.RideDecisionEngine
import com.example.domain.RidePlatform
import com.example.service.ServiceStatusHelper
import com.example.service.SystemIntegrationStatus
import com.example.ui.ShiftSummary
import com.example.ui.components.MovablePlnPerKmBox
import com.example.ui.components.ProfitGauge
import com.example.ui.theme.AmberSignal
import com.example.ui.theme.CrimsonSignal
import com.example.ui.theme.ElectricCyan
import com.example.ui.theme.EmeraldSignal

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun HudScreen(
  activeOffer: EvaluatedRide?,
  goals: ProfitGoals,
  integrationStatus: SystemIntegrationStatus,
  overlayServiceRunning: Boolean,
  shiftSummary: ShiftSummary,
  quickFareInput: String,
  quickPickupInput: String,
  quickTripInput: String,
  quickPlatform: RidePlatform,
  quickError: String?,
  onQuickFareChange: (String) -> Unit,
  onQuickPickupChange: (String) -> Unit,
  onQuickTripChange: (String) -> Unit,
  onQuickPlatformChange: (RidePlatform) -> Unit,
  onEvaluateManualOffer: () -> Unit,
  onTriggerSampleOffer: (RidePlatform, Double, Double, Double, Int) -> Unit,
  onDriverAction: (DriverAction) -> Unit,
  onDismissActiveOffer: () -> Unit,
  onToggleOverlayService: (Boolean) -> Unit,
  onRefreshStatus: () -> Unit,
  modifier: Modifier = Modifier,
) {
  val context = LocalContext.current
  var containerSize by remember { mutableStateOf(IntSize.Zero) }

  val notificationPermissionLauncher =
    rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { _ ->
      onRefreshStatus()
    }

  Box(
    modifier =
      modifier
        .fillMaxSize()
        .padding(horizontal = 16.dp)
        .onSizeChanged { containerSize = it },
  ) {
    LazyColumn(
      modifier =
        Modifier.fillMaxSize()
          .widthIn(max = 680.dp)
          .align(Alignment.TopCenter)
          .testTag("hud_lazy_column"),
      verticalArrangement = Arrangement.spacedBy(12.dp),
      contentPadding = PaddingValues(top = 74.dp, bottom = 20.dp),
    ) {
      // 1. Live Overlay & Auto-Detect Setup Card
      item {
        Card(
          colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
          shape = MaterialTheme.shapes.medium,
          border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline),
        ) {
          Column(modifier = Modifier.padding(16.dp)) {
            Row(
              modifier = Modifier.fillMaxWidth(),
              verticalAlignment = Alignment.CenterVertically,
            ) {
              Icon(
                imageVector = Icons.Filled.Layers,
                contentDescription = null,
                tint = MaterialTheme.colorScheme.primary,
              )
              Spacer(modifier = Modifier.width(10.dp))
              Column(modifier = Modifier.weight(1f)) {
                Text(
                  text = "Movable PLN/km Overlay Box",
                  style = MaterialTheme.typography.titleMedium,
                )
                Text(
                  text =
                    if (overlayServiceRunning && integrationStatus.overlayGranted) {
                      "Active • Drag the PLN/km box anywhere over Bolt & Uber"
                    } else {
                      "Enable permissions below to float over Bolt & Uber"
                    },
                  style = MaterialTheme.typography.bodyMedium,
                  color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
              }
              Switch(
                checked = goals.overlayEnabled && overlayServiceRunning,
                onCheckedChange = { enable ->
                  if (enable && !integrationStatus.overlayGranted) {
                    context.startActivity(ServiceStatusHelper.overlaySettingsIntent(context))
                  } else if (enable &&
                    !integrationStatus.postNotificationsGranted &&
                    Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU
                  ) {
                    notificationPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
                  } else {
                    onToggleOverlayService(enable)
                  }
                },
                modifier = Modifier.testTag("overlay_master_switch"),
              )
            }

            Spacer(modifier = Modifier.height(12.dp))

            IntegrationActionRow(
              title = "Floating Box Permission",
              subtitle =
                if (integrationStatus.overlayGranted) "Granted — draggable over Bolt / Uber"
                else "Required to display movable PLN/km box over Bolt / Uber",
              enabled = integrationStatus.overlayGranted,
              icon = Icons.Filled.Layers,
              testTag = "permission_overlay_button",
              onClick = {
                context.startActivity(ServiceStatusHelper.overlaySettingsIntent(context))
              },
            )

            Spacer(modifier = Modifier.height(8.dp))

            IntegrationActionRow(
              title = "Bolt & Uber Screen Reader",
              subtitle =
                if (integrationStatus.accessibilityEnabled) "Connected — reading incoming offers"
                else "Enable Accessibility to read fare & km on offer cards",
              enabled = integrationStatus.accessibilityEnabled,
              icon = Icons.Filled.AccessibilityNew,
              testTag = "permission_accessibility_button",
              onClick = {
                context.startActivity(ServiceStatusHelper.accessibilitySettingsIntent())
              },
            )

            Spacer(modifier = Modifier.height(8.dp))

            IntegrationActionRow(
              title = "Ride Notification Reader",
              subtitle =
                if (integrationStatus.notificationListenerEnabled) "Connected — watching notifications"
                else "Optional backup to catch push ride alerts",
              enabled = integrationStatus.notificationListenerEnabled,
              icon = Icons.Filled.NotificationsActive,
              testTag = "permission_notification_listener_button",
              onClick = {
                context.startActivity(ServiceStatusHelper.notificationListenerSettingsIntent())
              },
            )

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU &&
              !integrationStatus.postNotificationsGranted
            ) {
              Spacer(modifier = Modifier.height(8.dp))
              OutlinedButton(
                onClick = {
                  notificationPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
                },
                modifier =
                  Modifier.fillMaxWidth()
                    .minimumInteractiveComponentSize()
                    .testTag("permission_post_notifications_button"),
              ) {
                Text("Allow Status Notification (Android 13+)")
              }
            }
          }
        }
      }

      // 2. Quick Offer Check & Movable Box Tester
      item {
        Card(
          colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
          shape = MaterialTheme.shapes.medium,
          border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline),
        ) {
          Column(modifier = Modifier.padding(16.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
              Icon(
                imageVector = Icons.Filled.Calculate,
                contentDescription = null,
                tint = ElectricCyan,
              )
              Spacer(modifier = Modifier.width(8.dp))
              Text(
                text = "Quick PLN/km Check",
                style = MaterialTheme.typography.titleMedium,
              )
            }
            Spacer(modifier = Modifier.height(4.dp))
            Text(
              text = "Drag the small box at top-left anywhere. Test any fare and distance below.",
              style = MaterialTheme.typography.bodyMedium,
              color = MaterialTheme.colorScheme.onSurfaceVariant,
            )

            Spacer(modifier = Modifier.height(10.dp))

            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
              FilterChip(
                selected = quickPlatform == RidePlatform.BOLT,
                onClick = { onQuickPlatformChange(RidePlatform.BOLT) },
                label = { Text("Bolt") },
                modifier = Modifier.minimumInteractiveComponentSize().testTag("platform_chip_bolt"),
              )
              FilterChip(
                selected = quickPlatform == RidePlatform.UBER,
                onClick = { onQuickPlatformChange(RidePlatform.UBER) },
                label = { Text("Uber") },
                modifier = Modifier.minimumInteractiveComponentSize().testTag("platform_chip_uber"),
              )
            }

            Spacer(modifier = Modifier.height(8.dp))

            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.spacedBy(8.dp),
            ) {
              OutlinedTextField(
                value = quickFareInput,
                onValueChange = onQuickFareChange,
                label = { Text("Fare (PLN)") },
                singleLine = true,
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                modifier = Modifier.weight(1.1f).testTag("input_fare_pln"),
              )
              OutlinedTextField(
                value = quickPickupInput,
                onValueChange = onQuickPickupChange,
                label = { Text("Pickup km") },
                singleLine = true,
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                modifier = Modifier.weight(0.95f).testTag("input_pickup_km"),
              )
              OutlinedTextField(
                value = quickTripInput,
                onValueChange = onQuickTripChange,
                label = { Text("Trip km") },
                singleLine = true,
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                modifier = Modifier.weight(0.95f).testTag("input_trip_km"),
              )
            }

            if (quickError != null) {
              Spacer(modifier = Modifier.height(6.dp))
              Text(
                text = quickError,
                style = MaterialTheme.typography.bodyMedium,
                color = CrimsonSignal,
              )
            }

            Spacer(modifier = Modifier.height(10.dp))

            Button(
              onClick = onEvaluateManualOffer,
              modifier =
                Modifier.fillMaxWidth()
                  .minimumInteractiveComponentSize()
                  .testTag("evaluate_offer_button"),
            ) {
              Icon(
                imageVector = Icons.Filled.PlayArrow,
                contentDescription = null,
                modifier = Modifier.size(18.dp),
              )
              Spacer(modifier = Modifier.width(6.dp))
              Text("Update PLN/km Box", style = MaterialTheme.typography.labelLarge)
            }

            Spacer(modifier = Modifier.height(10.dp))
            Text(
              text = "One-Tap Polish Scenario Previews:",
              style = MaterialTheme.typography.labelSmall,
              color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
            Spacer(modifier = Modifier.height(6.dp))

            FlowRow(
              horizontalArrangement = Arrangement.spacedBy(8.dp),
              verticalArrangement = Arrangement.spacedBy(8.dp),
            ) {
              OutlinedButton(
                onClick = { onTriggerSampleOffer(RidePlatform.BOLT, 44.00, 1.1, 9.8, 17) },
                modifier = Modifier.minimumInteractiveComponentSize().testTag("sample_good_bolt"),
              ) {
                Icon(
                  imageVector = Icons.Filled.Bolt,
                  contentDescription = null,
                  tint = EmeraldSignal,
                  modifier = Modifier.size(16.dp),
                )
                Spacer(modifier = Modifier.width(4.dp))
                Text("Bolt 44 PLN / 10.9 km")
              }
              OutlinedButton(
                onClick = { onTriggerSampleOffer(RidePlatform.BOLT, 37.50, 3.0, 13.9, 33) },
                modifier = Modifier.minimumInteractiveComponentSize().testTag("sample_caution_uber"),
              ) {
                Text("Bolt 37.50 PLN / 16.9 km", color = CrimsonSignal)
              }
              OutlinedButton(
                onClick = { onTriggerSampleOffer(RidePlatform.UBER, 26.50, 2.4, 7.1, 16) },
                modifier = Modifier.minimumInteractiveComponentSize().testTag("sample_reject_bolt"),
              ) {
                Text("Uber 26.50 PLN / 9.5 km", color = AmberSignal)
              }
            }
          }
        }
      }

      // 3. Shift Telemetry Gauge Card
      item {
        Card(
          colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
          shape = MaterialTheme.shapes.medium,
          border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline),
        ) {
          Row(
            modifier = Modifier.fillMaxWidth().padding(16.dp),
            verticalAlignment = Alignment.CenterVertically,
          ) {
            ProfitGauge(
              currentPlnPerKm = activeOffer?.grossPlnPerKm ?: shiftSummary.averagePlnPerKm,
              minPlnPerKm = goals.minPlnPerKm,
              targetPlnPerKm = goals.targetPlnPerKm,
            )
            Spacer(modifier = Modifier.width(16.dp))
            Column(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(6.dp)) {
              Text(
                text =
                  if (activeOffer != null) "Current Request Rate" else "Shift Average Rate",
                style = MaterialTheme.typography.titleMedium,
              )
              StatLine(
                label = "Offers Evaluated",
                value = "${shiftSummary.totalOffers}",
              )
              StatLine(
                label = "Goal Target",
                value = "${RideDecisionEngine.formatPln(goals.targetPlnPerKm)} PLN/km",
              )
              StatLine(
                label = "Minimum Rate",
                value = "${RideDecisionEngine.formatPln(goals.minPlnPerKm)} PLN/km",
              )
            }
          }
        }
      }
    }

    // Small movable PLN/km box floating over the top-left corner (freely draggable anywhere)
    MovablePlnPerKmBox(
      activeOffer = activeOffer,
      containerSize = containerSize,
      onDismiss = onDismissActiveOffer,
      modifier = Modifier.align(Alignment.TopStart).padding(top = 8.dp),
    )
  }
}

@Composable
private fun IntegrationActionRow(
  title: String,
  subtitle: String,
  enabled: Boolean,
  icon: ImageVector,
  testTag: String,
  onClick: () -> Unit,
) {
  Surface(
    onClick = onClick,
    shape = RoundedCornerShape(12.dp),
    color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.65f),
    border =
      BorderStroke(
        1.dp,
        if (enabled) EmeraldSignal.copy(alpha = 0.5f) else MaterialTheme.colorScheme.outline,
      ),
    modifier = Modifier.fillMaxWidth().minimumInteractiveComponentSize().testTag(testTag),
  ) {
    Row(
      modifier = Modifier.padding(horizontal = 12.dp, vertical = 10.dp),
      verticalAlignment = Alignment.CenterVertically,
    ) {
      Icon(
        imageVector = icon,
        contentDescription = null,
        tint = if (enabled) EmeraldSignal else MaterialTheme.colorScheme.onSurfaceVariant,
        modifier = Modifier.size(22.dp),
      )
      Spacer(modifier = Modifier.width(12.dp))
      Column(modifier = Modifier.weight(1f)) {
        Text(text = title, style = MaterialTheme.typography.bodyLarge, fontWeight = FontWeight.Medium)
        Text(
          text = subtitle,
          style = MaterialTheme.typography.bodyMedium,
          color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
      }
      Spacer(modifier = Modifier.width(8.dp))
      Icon(
        imageVector =
          if (enabled) Icons.Filled.CheckCircle else Icons.Outlined.RadioButtonUnchecked,
        contentDescription = if (enabled) "Enabled" else "Tap to configure",
        tint = if (enabled) EmeraldSignal else AmberSignal,
        modifier = Modifier.size(22.dp),
      )
    }
  }
}

@Composable
private fun StatLine(label: String, value: String) {
  Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
    Text(
      text = label,
      style = MaterialTheme.typography.bodyMedium,
      color = MaterialTheme.colorScheme.onSurfaceVariant,
    )
    Text(
      text = value,
      style = MaterialTheme.typography.labelLarge,
      color = MaterialTheme.colorScheme.onSurface,
    )
  }
}
